<table width="100%" style="color:#000">
  <tr>
    <td><img src="imagenes/logo_about.png" /></td>
    <td><p>Desarrollado por:<br/>
      <b>Ing. Hugo César Gutiérrez Corzo</b><br/>
      <b>Ing. Mario Alberto Villatoro Diaz</b></p>
      <p><em><strong>Sistema de Administraci&oacute;n BETA 0.1</strong><br />TUViSiON Tele-Cable</em></p></td>
  </tr>
</table>