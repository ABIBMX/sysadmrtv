<form onsubmit="return false;">
	<div id="modulo" style="display:none;">3</div>
	<table width="100%" cellpadding="2px">
    	<tr> 
        	<td>Nombre</td><td><input name="id_cliente" id="id_cliente" readonly="readonly" style="width:110px;font-size:12px;" type="text" maxlength="12" />&nbsp;<img style="cursor:pointer;position:relative; top:4px;" onclick="contenedor_cliente='id_cliente';createWindow('Buscar Cliente',450,310 ,1,false,true,1);" src="imagenes/popup.png" /></td></tr>
        </tr>
        <tr> 
        	<td>Desde</td><td></td></tr>
        </tr>
        <tr> 
        	<td>Hasta</td><td></td></tr>
        </tr>
        <tr> 
        	<td>Tipo Ingreso</td><td></td></tr>
        </tr>
        <tr> 
        	<td>Monto</td><td></td></tr>
        </tr>
       	
    </table>
</form>