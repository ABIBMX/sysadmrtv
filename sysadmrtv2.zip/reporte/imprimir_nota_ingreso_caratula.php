<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 12">
<meta name=Originator content="Microsoft Word 12">
<link rel=File-List href="recibo_pago_ok___archivos/filelist.xml">
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>Microsoft</o:Author>
  <o:LastAuthor>Microsoft</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>103</o:TotalTime>
  <o:Created>2019-09-05T02:50:00Z</o:Created>
  <o:LastSaved>2019-09-05T02:50:00Z</o:LastSaved>
  <o:Pages>3</o:Pages>
  <o:Words>592</o:Words>
  <o:Characters>3257</o:Characters>
  <o:Company>Microsoft</o:Company>
  <o:Lines>27</o:Lines>
  <o:Paragraphs>7</o:Paragraphs>
  <o:CharactersWithSpaces>3842</o:CharactersWithSpaces>
  <o:Version>12.00</o:Version>
 </o:DocumentProperties>
</xml><![endif]-->
<link rel=dataStoreItem href="recibo_pago_ok___archivos/item0001.xml"
target="recibo_pago_ok___archivos/props0002.xml">
<link rel=themeData href="recibo_pago_ok___archivos/themedata.thmx">
<link rel=colorSchemeMapping
href="recibo_pago_ok___archivos/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:SpellingState>Clean</w:SpellingState>
  <w:GrammarState>Clean</w:GrammarState>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:HyphenationZone>21</w:HyphenationZone>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>ES-MX</w:LidThemeOther>
  <w:LidThemeAsian>X-NONE</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:DontVertAlignCellWithSp/>
   <w:DontBreakConstrainedForcedTables/>
   <w:DontVertAlignInTxbx/>
   <w:Word11KerningPairs/>
   <w:CachedColBalance/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="--"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="true"
  DefSemiHidden="true" DefQFormat="false" DefPriority="99"
  LatentStyleCount="267">
  <w:LsdException Locked="false" Priority="0" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 9"/>
  <w:LsdException Locked="false" Priority="35" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" Priority="10" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" Priority="11" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" Priority="22" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" Priority="59" SemiHidden="false"
   UnhideWhenUsed="false" Name="Table Grid"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" QFormat="true" Name="TOC Heading"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:-536869121 1107305727 33554432 0 415 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-536859905 -1073732485 9 0 511 0;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoCommentText, li.MsoCommentText, div.MsoCommentText
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Texto comentario Car";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
span.MsoCommentReference
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:blue;
	mso-themecolor:hyperlink;
	text-decoration:underline;
	text-underline:single;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-noshow:yes;
	mso-style-priority:99;
	color:purple;
	mso-themecolor:followedhyperlink;
	text-decoration:underline;
	text-underline:single;}
p.MsoCommentSubject, li.MsoCommentSubject, div.MsoCommentSubject
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-parent:"Texto comentario";
	mso-style-link:"Asunto del comentario Car";
	mso-style-next:"Texto comentario";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;
	font-weight:bold;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Texto de globo Car";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:8.0pt;
	font-family:"Tahoma","sans-serif";
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-fareast-language:EN-US;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	text-align:center;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	text-align:center;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	text-align:center;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	text-align:center;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
span.TextocomentarioCar
	{mso-style-name:"Texto comentario Car";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Texto comentario";
	mso-ansi-font-size:10.0pt;
	mso-bidi-font-size:10.0pt;}
span.AsuntodelcomentarioCar
	{mso-style-name:"Asunto del comentario Car";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-parent:"Texto comentario Car";
	mso-style-link:"Asunto del comentario";
	mso-ansi-font-size:10.0pt;
	mso-bidi-font-size:10.0pt;
	font-weight:bold;}
span.TextodegloboCar
	{mso-style-name:"Texto de globo Car";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Texto de globo";
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;
	font-family:"Tahoma","sans-serif";
	mso-ascii-font-family:Tahoma;
	mso-hansi-font-family:Tahoma;
	mso-bidi-font-family:Tahoma;}
span.SpellE
	{mso-style-name:"";
	mso-spl-e:yes;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
.MsoPapDefault
	{mso-style-type:export-only;
	text-align:center;
	line-height:115%;}

@page{
  
  margin:0mm;
  size:Letter;
}
@media print{
  size: Letter portrait;
}  


@page Section1
	{size:612.0pt 792.0pt;
	margin:28.4pt 37.9pt 35.45pt 1.0cm;
	mso-header-margin:35.4pt;
	mso-footer-margin:35.4pt;
	mso-paper-source:0;}
div.Section1
	{page:Section1;}
 /* List Definitions */
 @list l0
	{mso-list-id:1035542949;
	mso-list-type:hybrid;
	mso-list-template-ids:-979368744 134873103 134873113 134873115 134873103 134873113 134873115 134873103 134873113 134873115;}
@list l0:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Tabla normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-qformat:yes;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
table.MsoTableGrid
	{mso-style-name:"Tabla con cuadrícula";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-priority:59;
	mso-style-unhide:no;
	border:solid black 1.0pt;
	mso-border-themecolor:text1;
	mso-border-alt:solid black .5pt;
	mso-border-themecolor:text1;
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-border-insideh:.5pt solid black;
	mso-border-insideh-themecolor:text1;
	mso-border-insidev:.5pt solid black;
	mso-border-insidev-themecolor:text1;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="4098"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>
<?php
  require_once('../config.php');
  require_once('../conexion.php');
  require_once('../funciones.php');


$query = "select i.id_ingreso, i.id_cliente, i.monto_total,i.fecha,i.observaciones,i.folio_nota,concat(c.nombre,' ',c.apellido_paterno,' ',c.apellido_materno), s.nombre,c.nombre,c.apellido_paterno,c.apellido_materno,c.id_calle,c.numero,c.tarifa,c.fecha_contrato,c.num_contrato,c.colonia,c.numero_interior,c.cp,c.telefono,c.rfc, c.correo from ingresos i, clientes c, sucursales s where s.id_sucursal=c.id_sucursal and c.id_cliente = i.id_cliente and i.id_cliente='".addslashes($_POST['id_cliente'])."'";
  
  $registro_ingreso = @devolverValorQuery($query);

  if($registro_ingreso[0]!="")
  {
    //OBTENEMOS LOS DATOS
    $id_ingreso = $registro_ingreso[0];
    $id_cliente = $registro_ingreso[1];
    $monto_total= $registro_ingreso[2];
    $fecha    = $registro_ingreso[3];
    $observaciones = $registro_ingreso[4];
    $folio    = $registro_ingreso[5];
    $nombre   = $registro_ingreso[8];
    $sucursal   = $registro_ingreso[7];
    $paterno= $registro_ingreso[9];
    $materno =$registro_ingreso[10];
    $id_calle=$registro_ingreso[11];
    $numerocasa=$registro_ingreso[12];
    $tarifa=$registro_ingreso[13];
    $tarifa=$tarifa*30;
    $fecha_contrato=$registro_ingreso[14];
    $nocontrato=$registro_ingreso[15];
    $numero_interior=$registro_ingreso[17];
    $colonia=$registro_ingreso[16];
    $cp=$registro_ingreso[18];
    $telefono=$registro_ingreso[19];
    $rfc=$registro_ingreso[20];
    $correo=$registro_ingreso[21];
    $query2="select nombre from cat_calles where id_calle=".$id_calle;
    $calletmp=@devolverValorQuery($query2);
    $calle=$calletmp[0];

    $query3="select fecha_atencion,importe_inputable from reporte_servicios where id_cliente='".$id_cliente."' and id_peticion=1";
    $datosInstalacion=@devolverValorQuery($query3);
    $fecha_instalacion=$datosInstalacion[0];
    $importe_instalacion=0;

    $query4="select m.id_tipo_ingreso,m.monto from montos m where m.id_ingreso =(select i.id_ingreso from ingresos i where  i.id_cliente='".$id_cliente."')";
    
    $tabla = mysqli_query($conexion,$query4);
    $tmp=0;
    $total_tv_adicional=0;
      while ($registro=mysqli_fetch_array($tabla)) {      
         if ($registro[0]==1){
           $importe_instalacion=$registro[1];
         }
         if($registro[0]==2){
          $tmp++;
          $total_tv_adicional+=$registro[1];
         }
     echo $registro[0]."-";
      
     } 
  

    }
?>
<body lang=ES-MX link=blue vlink=purple style='tab-interval:35.4pt'>

<div class=Section1>

<br><br><br>
<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=304 valign=top style='width:182.6pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><br><img src="image001.jpg"></p>
  </td>
  <td width=617 valign=top style='width:370.15pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-left:none;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>TUVISION TELECABLE<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>MARLA SANTAELLA
  RODRIGUEZ<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>SARM800402837<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>CALLE VENUSTIANO
  CARRANZA, SN. COL CENTRO<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>SANTA MARIA
  ZACATEPEC<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>OAXACA</span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=921 colspan=10 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>SUSCRIPTOR</b><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:30.8pt'>
  <td width=307 colspan=3 style='width:184.25pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:30.8pt'>
  <p class=MsoNormal style='line-height:normal'><?php echo $nombre; ?></p>
  </td>
  <td width=307 colspan=3 style='width:184.25pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:30.8pt'>
  <p class=MsoNormal style='line-height:normal'><?php echo $paterno; ?></p>
  </td>
  <td width=307 colspan=4 style='width:184.25pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:30.8pt'>
  <p class=MsoNormal style='line-height:normal'><?php echo $materno; ?></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;height:13.55pt'>
  <td width=307 colspan=3 style='width:184.25pt;border-top:none;border-left:
  solid black 1.0pt;mso-border-left-themecolor:text1;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;border-right:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.55pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Nombre(s)<o:p></o:p></span></p>
  </td>
  <td width=307 colspan=3 style='width:184.25pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.55pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Apellido Paterno<o:p></o:p></span></p>
  </td>
  <td width=307 colspan=4 style='width:184.25pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.55pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Apellido Materno<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;height:13.55pt'>
  <td width=921 colspan=10 style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt;height:13.55pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>DOMICILIO</b><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4;height:56.25pt'>
  <td width=198 style='width:118.8pt;border:solid black 1.0pt;mso-border-themecolor:
  text1;border-top:none;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:
  text1;mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:
  white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:56.25pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $calle; ?><o:p></o:p></span></p>
  </td>
  <td width=95 style='width:2.0cm;border-top:none;border-left:none;border-bottom:
  solid black 1.0pt;mso-border-bottom-themecolor:text1;border-right:solid black 1.0pt;
  mso-border-right-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:56.25pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $numerocasa; ?><o:p></o:p></span></p>
  </td>
  <td width=71 colspan=2 style='width:42.55pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:56.25pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $numero_interior; ?><o:p></o:p></span></p>
  </td>
  <td width=163 style='width:97.8pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:56.25pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $colonia; ?><o:p></o:p></span></p>
  </td>
  <td width=191 colspan=3 style='width:114.8pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:56.25pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $sucursal; ?><o:p></o:p></span></p>
  </td>
  <td width=106 style='width:63.8pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:56.25pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>OAXACA<o:p></o:p></span></p>
  </td>
  <td width=97 style='width:58.3pt;border-top:none;border-left:none;border-bottom:
  solid black 1.0pt;mso-border-bottom-themecolor:text1;border-right:solid black 1.0pt;
  mso-border-right-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:56.25pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $cp; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5;height:13.8pt'>
  <td width=198 style='width:118.8pt;border-top:none;border-left:solid black 1.0pt;
  mso-border-left-themecolor:text1;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:none;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:
  text1;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-bottom-alt:solid black .5pt;mso-border-bottom-themecolor:text1;
  background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt;height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>CALLE<o:p></o:p></span></p>
  </td>
  <td width=95 style='width:2.0cm;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'># EXT<o:p></o:p></span></p>
  </td>
  <td width=71 colspan=2 style='width:42.55pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'># INT<o:p></o:p></span></p>
  </td>
  <td width=163 style='width:97.8pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>COLONIA<o:p></o:p></span></p>
  </td>
  <td width=191 colspan=3 style='width:114.8pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>ALCALDIA/MUNICIPIO<o:p></o:p></span></p>
  </td>
  <td width=106 style='width:63.8pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>ESTADO<o:p></o:p></span></p>
  </td>
  <td width=97 style='width:58.3pt;border-top:none;border-left:none;border-bottom:
  solid black 1.0pt;mso-border-bottom-themecolor:text1;border-right:solid black 1.0pt;
  mso-border-right-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>CP<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:6;mso-yfti-lastrow:yes;height:13.8pt'>
  <td width=293 colspan=2 style='width:175.5pt;border-top:none;border-left:
  solid black 1.0pt;mso-border-left-themecolor:text1;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;border-right:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>TELEFONO<span style='mso-spacerun:yes'>   
  </span>FIJO<span style='mso-spacerun:yes'>   </span>___<span
  style='mso-spacerun:yes'>     </span>MOVIL<span style='mso-spacerun:yes'>  
  </span><b>X</b><o:p></o:p></span></p>
  </td>
  <td width=234 colspan=3 style='width:140.35pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:white;mso-background-themecolor:
  background1;padding:0cm 5.4pt 0cm 5.4pt;height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $telefono; ?><o:p></o:p></span></p>
  </td>
  <td width=109 colspan=2 style='width:65.2pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>RFC<o:p></o:p></span></p>
  </td>
  <td width=286 colspan=3 style='width:171.7pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;background:white;mso-background-themecolor:
  background1;padding:0cm 5.4pt 0cm 5.4pt;height:13.8pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $rfc; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <![if !supportMisalignedColumns]>
 <tr height=0>
  <td width=159 style='border:none'></td>
  <td width=67 style='border:none'></td>
  <td width=13 style='border:none'></td>
  <td width=41 style='border:none'></td>
  <td width=119 style='border:none'></td>
  <td width=88 style='border:none'></td>
  <td width=21 style='border:none'></td>
  <td width=73 style='border:none'></td>
  <td width=92 style='border:none'></td>
  <td width=75 style='border:none'></td>
 </tr>
 <![endif]>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>
<br><br>
<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=928 colspan=5 valign=top style='width:556.55pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>SERVICIO DE TELEVISION DE PAGA</b><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:50.05pt'>
  <td width=262 style='width:157.35pt;border-top:none;border-left:solid windowtext 1.0pt;
  border-bottom:none;border-right:solid windowtext 1.0pt;mso-border-left-alt:
  solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:
  #F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt;height:50.05pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>DESCRIPCION PAQUETE/OFERTA<o:p></o:p></span></p>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>(INCISO I <span class=SpellE>Nom</span>
  numeral 5.2.1)<o:p></o:p></span></p>
  </td>
  <td width=305 colspan=2 style='width:183.2pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;mso-border-left-alt:
  solid windowtext .5pt;background:#F2F2F2;mso-background-themecolor:background1;
  mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;height:50.05pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>TARIFA<o:p></o:p></span></p>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>FOLIO IFT: 183017<o:p></o:p></span></p>
  </td>
  <td width=181 style='width:108.3pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt;height:50.05pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>FECHA DE PAGO<o:p></o:p></span></p>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Modalidad Mensualidades fijas POR
  ADELANTADO<o:p></o:p></span></p>
  </td>
  <td width=180 style='width:107.7pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:50.05pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><?php echo $fecha_contrato; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;height:28.1pt'>
  <td width=262 rowspan=2 style='width:157.35pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:28.1pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>SERVICIO DE TELEVISION RESTRINGIDA<o:p></o:p></span></p>
  </td>
  <td width=196 style='width:117.4pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid windowtext .5pt;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:28.1pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Total mensualidad<o:p></o:p></span></p>
  </td>
  <td width=110 style='width:65.8pt;border:solid black 1.0pt;mso-border-themecolor:
  text1;border-left:none;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:
  text1;mso-border-bottom-alt:solid black .5pt;mso-border-bottom-themecolor:
  text1;mso-border-right-alt:solid black .5pt;mso-border-right-themecolor:text1;
  padding:0cm 5.4pt 0cm 5.4pt;height:28.1pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>$<?php echo $tarifa; ?> MN<o:p></o:p></span></p>
  </td>
  <td width=181 style='width:108.3pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:28.1pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>VIGENCIA DEL CONTRATO<o:p></o:p></span></p>
  </td>
  <td width=180 style='width:107.7pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt;height:28.1pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>INDEFINIDO<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;height:41.95pt'>
  <td width=196 style='width:117.4pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid windowtext .5pt;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:41.95pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Aplica Tarifa por <span class=SpellE>Reconexión</span><o:p></o:p></span></p>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>SI<span style='mso-spacerun:yes'> 
  </span><b>X</b><span style='mso-spacerun:yes'>   </span>NO<span
  style='mso-spacerun:yes'>  </span>___<o:p></o:p></span></p>
  </td>
  <td width=110 style='width:65.8pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt;height:41.95pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>$100.00 MN<o:p></o:p></span></p>
  </td>
  <td width=181 style='width:108.3pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:41.95pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>PENALIDAD<o:p></o:p></span></p>
  </td>
  <td width=180 style='width:107.7pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt;height:41.95pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>N/A<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4;mso-yfti-lastrow:yes;height:14.2pt'>
  <td width=928 colspan=5 style='width:556.55pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt;height:14.2pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>En el Estado de cuenta y/o factura se podrá
  visualizar la fecha de corte del servicio y fecha de pago<o:p></o:p></span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>
<br><br>
<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=921 colspan=4 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>INSTALACION DE SERVICIO</b><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:21.9pt'>
  <td width=230 style='width:138.15pt;border-top:none;border-left:solid black 1.0pt;
  mso-border-left-themecolor:text1;border-bottom:solid windowtext 1.0pt;
  border-right:none;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:
  text1;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-bottom-alt:solid windowtext .5pt;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;
  height:21.9pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Domicilio <span class=SpellE>Instalacion</span><o:p></o:p></span></p>
  </td>
  <td width=691 colspan=3 valign=top style='width:414.6pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-bottom-alt:solid black .5pt;mso-border-bottom-themecolor:text1;
  mso-border-right-alt:solid black .5pt;mso-border-right-themecolor:text1;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.9pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><?php echo $calle." #".$numerocasa.", ".$sucursal.", OAXACA."; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=230 style='width:138.15pt;border-top:none;border-left:solid black 1.0pt;
  mso-border-left-themecolor:text1;border-bottom:solid windowtext 1.0pt;
  border-right:none;mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:
  solid windowtext .5pt;mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:
  text1;mso-border-bottom-alt:solid windowtext .5pt;background:#F2F2F2;
  mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Fecha<o:p></o:p></span></p>
  </td>
  <td width=230 valign=top style='width:138.2pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><?php echo $fecha_instalacion; ?><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=230 valign=top style='width:138.2pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Hora<o:p></o:p></span></p>
  </td>
  <td width=230 valign=top style='width:138.2pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;height:21.0pt'>
  <td width=230 style='width:138.15pt;border-top:none;border-left:solid black 1.0pt;
  mso-border-left-themecolor:text1;border-bottom:solid windowtext 1.0pt;
  border-right:none;mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:
  solid windowtext .5pt;mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:
  text1;mso-border-bottom-alt:solid windowtext .5pt;background:#F2F2F2;
  mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.0pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Costo<o:p></o:p></span></p>
  </td>
  <td width=691 colspan=3 valign=top style='width:414.6pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-bottom-alt:solid black .5pt;mso-border-bottom-themecolor:text1;
  mso-border-right-alt:solid black .5pt;mso-border-right-themecolor:text1;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.0pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>$<?php echo $importe_instalacion;?> MN<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4;mso-yfti-lastrow:yes;height:21.0pt'>
  <td width=921 colspan=4 style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid windowtext .5pt;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;mso-border-top-alt:
  solid windowtext .5pt;background:#F2F2F2;mso-background-themecolor:background1;
  mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;height:21.0pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>“EL PROVEEDOR”
  deberá efectuar las instalaciones y empezar a prestar el servicio en un plazo
  que no exceda de 10 días naturales posteriores a la firma del contrato.<o:p></o:p></span></p>
  </td>
 </tr>
</table>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br>
<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=304 valign=top style='width:182.6pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><br><img src="image001.jpg"></p>
  </td>
  <td width=617 valign=top style='width:370.15pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-left:none;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>TUVISION TELECABLE<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>MARLA SANTAELLA
  RODRIGUEZ<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>SARM800402837<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>CALLE VENUSTIANO
  CARRANZA, SN. COL CENTRO<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>SANTA MARIA
  ZACATEPEC<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>OAXACA</span></p>
  </td>
 </tr>
</table>

<br>
<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=928 colspan=6 valign=top style='width:556.55pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>METODO DE PAGO</b><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width=317 colspan=2 rowspan=2 valign=top style='width:190.1pt;border:
  solid black 1.0pt;mso-border-themecolor:text1;border-top:none;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;
  mso-border-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><span
  style='mso-spacerun:yes'>  </span><b>X</b><span style='mso-spacerun:yes'> 
  </span>Efectivo<o:p></o:p></span></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>___ Domiciliado con
  tarjeta<o:p></o:p></span></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>___ Transferencia
  Bancaria<o:p></o:p></span></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>___ Depósito a
  cuenta Bancaria<o:p></o:p></span></p>
  </td>
  <td width=611 colspan=4 valign=top style='width:366.45pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:#F2F2F2;
  mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Datos para el <span
  class=SpellE>metodo</span> de pago elegido.<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=614 colspan=4 style='width:13.0cm;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>EFECTIVO<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3'>
  <td width=921 colspan=6 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><b>AUTORIZACION PARA CARGO CON
  TARJETA DE CREDITO O DEBITO</b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4'>
  <td width=921 colspan=6 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>Por
  medio de la presente SI__<span style='mso-spacerun:yes'>  </span>NO <b>X</b><span
  style='mso-spacerun:yes'>   </span>autorizo a “EL PROVEEDOR”, para que cargue
  a mi tarjeta de crédito o débito, la cantidad por concepto de servicios que
  mensualmente me presta. La vigencia de los cargos será por<span
  style='mso-spacerun:yes'> _______ </span>meses.</p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><o:p>&nbsp;</o:p></p>
  <br>
  <center>_____________________</center>
  <p class=MsoNormal style='line-height:normal'>FIRMA</p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5'>
  <td width=104 valign=top style='width:62.1pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>BANCO</p>
  </td>
  <td width=357 colspan=2 valign=top style='width:214.2pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>N/A</p>
  </td>
  <td width=198 valign=top style='width:118.95pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>NUMERO<span
  style='mso-spacerun:yes'>  </span>DE TARJETA</p>
  </td>
  <td width=263 colspan=2 valign=top style='width:157.5pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>N/A</p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:6'>
  <td width=104 valign=top style='width:62.1pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>1-</p>
  </td>
  <td width=357 colspan=2 valign=top style='width:214.2pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>N/A</p>
  </td>
  <td width=198 valign=top style='width:118.95pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>1-</p>
  </td>
  <td width=263 colspan=2 valign=top style='width:157.5pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>N/A</p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:7'>
  <td width=921 colspan=6 valign=top style='width:556.55pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><b>SERVICIOS ADICIONALES</b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:8'>
  <td width=104 valign=top style='width:62.1pt;border-top:none;border-left:
  solid black 1.0pt;mso-border-left-themecolor:text1;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;border-right:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>DESCRIPCION</p>
  </td>
  <td width=204 valign=top style='width:122.1pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'>COSTO</p>
  </td>
  <td width=154 valign=top style='width:92.1pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>N/A</p>
  </td>
  <td width=198 valign=top style='width:118.95pt;border:none;border-bottom:
  solid black 1.0pt;mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>DESCRIPCION</p>
  </td>
  <td width=109 valign=top style='width:65.35pt;border:none;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>COSTO</p>
  </td>
  <td width=154 valign=top style='width:92.15pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>N/A</p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:9;mso-yfti-lastrow:yes'>
  <td width=471 colspan=3 valign=top style='width:282.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>N/A</p>
  </td>
  <td width=451 colspan=3 valign=top style='width:270.8pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'>N/A</p>
  </td>
 </tr>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=921 colspan=9 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>CONCEPTOS FACTURABLES</b><o:p></o:p></span></p>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>(<span class=SpellE>Ejem</span>. Costo por
  cambio de domicilio, Costos Administrativos adicionales)<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width=56 valign=top style='width:33.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>1<o:p></o:p></span></p>
  </td>
  <td width=425 colspan=4 valign=top style='width:9.0cm;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Instalación<o:p></o:p></span></p>
  </td>
  <td width=47 valign=top style='width:1.0cm;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>2<o:p></o:p></span></p>
  </td>
  <td width=393 colspan=3 valign=top style='width:235.5pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  class=SpellE><span style='font-size:9.0pt;font-family:"Arial","sans-serif"'><?php if ($tmp>0) echo "Television Adicional ('.$tmp.' tv) "?></span></span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=198 colspan=2 valign=top style='width:118.8pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>DESCRIPCION<o:p></o:p></span></p>
  </td>
  <td width=109 valign=top style='width:65.45pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>COSTO:<o:p></o:p></span></p>
  </td>
  <td width=154 valign=top style='width:92.1pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>$<?php echo $importe_instalacion;?> MN<o:p></o:p></span></p>
  </td>
  <td width=186 colspan=3 valign=top style='width:111.8pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:#F2F2F2;
  mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>DESCRIPCION<o:p></o:p></span></p>
  </td>
  <td width=121 valign=top style='width:72.45pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>COSTO:<o:p></o:p></span></p>
  </td>
  <td width=154 valign=top style='width:92.15pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>$<?php echo $total_tv_adicional;?> MN<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;mso-yfti-lastrow:yes;height:22.7pt'>
  <td width=461 colspan=4 valign=top style='width:276.35pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:22.7pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>INSTALACION<o:p></o:p></span></p>
  </td>
  <td width=461 colspan=5 valign=top style='width:276.4pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:white;
  mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;height:
  22.7pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><?php if($tmp>0) echo 'TELEVISION (ES) ADICIONAL(ES)';?><o:p></o:p></span></p>
  </td>
 </tr>
 <![if !supportMisalignedColumns]>
 <tr height=0>
  <td width=56 style='border:none'></td>
  <td width=108 style='border:none'></td>
  <td width=94 style='border:none'></td>
  <td width=113 style='border:none'></td>
  <td width=21 style='border:none'></td>
  <td width=47 style='border:none'></td>
  <td width=90 style='border:none'></td>
  <td width=101 style='border:none'></td>
  <td width=116 style='border:none'></td>
 </tr>
 <![endif]>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=921 colspan=9 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><b>EL SUSCRIPTOR AUTORIZA SE LE
  ENVIE POR CORREO ELECTRONICO</b><o:p></o:p></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:17.7pt'>
  <td width=104 valign=top style='width:62.1pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt;height:17.7pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>FACTURA<o:p></o:p></p>
  </td>
  <td width=142 colspan=2 valign=top style='width:3.0cm;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt;
  height:17.7pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>SI <b> X </b><span
  style='mso-spacerun:yes'>     </span>NO ___<o:p></o:p></p>
  </td>
  <td width=225 colspan=2 valign=top style='width:134.7pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:#F2F2F2;
  mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.7pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>Carta
  de Derechos Mínimos<o:p></o:p></p>
  </td>
  <td width=118 valign=top style='width:70.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:17.7pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>SI<span
  style='mso-spacerun:yes'>  </span><b>X</b><span style='mso-spacerun:yes'>  
  </span>NO ___<o:p></o:p></p>
  </td>
  <td width=189 colspan=2 valign=top style='width:4.0cm;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:#F2F2F2;
  mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.7pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>Contrato
  de Adhesión<o:p></o:p></p>
  </td>
  <td width=144 valign=top style='width:86.65pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:17.7pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'>SI<span
  style='mso-spacerun:yes'>  </span><b>X</b><span style='mso-spacerun:yes'>  
  </span>NO ___<o:p></o:p></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;mso-yfti-lastrow:yes;height:49.15pt'>
  <td width=198 colspan=2 style='width:118.8pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt;height:49.15pt'>
  <p class=MsoNormal style='line-height:normal'>CORREO ELECTRONICO AUTORIZADO<o:p></o:p></p>
  </td>
  <td width=263 colspan=2 style='width:157.55pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:49.15pt'>
  <p class=MsoNormal style='line-height:normal'> <?php echo $correo; ?><o:p>&nbsp;</o:p></p>
  </td>
  <td width=230 colspan=3 style='width:138.2pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt;height:49.15pt'>
  <p class=MsoNormal style='line-height:normal'>FIRMA DEL SUSCRIPTOR<o:p></o:p></p>
  </td>
  <td width=230 colspan=2 style='width:138.2pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:white;mso-background-themecolor:background1;padding:0cm 5.4pt 0cm 5.4pt;
  height:49.15pt'><p class=MsoNormal style='line-height:normal'><?php echo "  <img src=http://tuvisiontelecable.com.mx/api/public/storage/upload/".$id_cliente.".jpg width='50%''>";  ?><o:p>&nbsp;</o:p></p>  
  
  </td>
 </tr>
 <![if !supportMisalignedColumns]>
 <tr height=0>
  <td width=99 style='border:none'></td>
  <td width=74 style='border:none'></td>
  <td width=35 style='border:none'></td>
  <td width=172 style='border:none'></td>
  <td width=7 style='border:none'></td>
  <td width=95 style='border:none'></td>
  <td width=89 style='border:none'></td>
  <td width=67 style='border:none'></td>
  <td width=110 style='border:none'></td>
 </tr>
 <![endif]>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=921 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>AUTORIZACION PARA USO DE INFORMACION DEL
  SUSCRIPTOR</b><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes'>
  <td width=921 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-top:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>1. El Suscriptor
  SI<span style='mso-spacerun:yes'>  </span><b>X</b><span style='mso-spacerun:yes'> 
  </span>NO ___<span style='mso-spacerun:yes'>    </span>autoriza que su
  información sea cedida o transmitida por el proveedor a terceros<span
  style='mso-spacerun:yes'>  </span>con fines mercadotécnicos o publicitarios.<span
  style='mso-spacerun:yes'>  </span>FIRMA __________________<o:p></o:p></span></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>2. El Suscriptor
  acepta SI<span style='mso-spacerun:yes'>  </span><b>X</b><span
  style='mso-spacerun:yes'>    </span>NO ___<span style='mso-spacerun:yes'> 
  </span>recibir llamadas del proveedor de promociones de servicios o paquetes.
  FIRMA ______________<o:p></o:p></span></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=928 colspan=3 valign=top style='width:556.55pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>MEDIOS DE CONTACTO DEL PROVEEDOR PARA
  QUEJAS, ACLARACIONES, CONSULTAS Y CANCELACIONES</b><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:15.6pt'>
  <td width=279 style='width:167.45pt;border:solid black 1.0pt;mso-border-themecolor:
  text1;border-top:none;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:
  text1;mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:
  #F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.6pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>TELEFONO<o:p></o:p></span></p>
  </td>
  <td width=250 valign=top style='width:149.8pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:15.6pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>9993306039<o:p></o:p></span></p>
  </td>
  <td width=399 valign=top style='width:239.3pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:15.6pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Disponible las 24
  horas del <span class=SpellE>dia</span> los 7 días de la semana<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;height:21.5pt'>
  <td width=279 style='width:167.45pt;border:solid black 1.0pt;mso-border-themecolor:
  text1;border-top:none;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:
  text1;mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:
  #F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.5pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>CORREO ELECTRONICO<o:p></o:p></span></p>
  </td>
  <td width=250 valign=top style='width:149.8pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:21.5pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>contacto@tuvision.tv<o:p></o:p></span></p>
  </td>
  <td width=399 valign=top style='width:239.3pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt;height:21.5pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Disponible las 24
  horas del <span class=SpellE>dia</span> los 7 días de la semana<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;mso-yfti-lastrow:yes;height:20.4pt'>
  <td width=279 style='width:167.45pt;border:solid black 1.0pt;mso-border-themecolor:
  text1;border-top:none;mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:
  text1;mso-border-alt:solid black .5pt;mso-border-themecolor:text1;background:
  #F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:242;
  padding:0cm 5.4pt 0cm 5.4pt;height:20.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>CENTROS DE ATENCION A CLIENTES<o:p></o:p></span></p>
  </td>
  <td width=649 colspan=2 valign=top style='width:389.1pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-alt:solid black .5pt;mso-border-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Consultar horarios
  disponibles, días disponibles y centros de atención a clientes disponibles en
  la página de internet www.tuvision.tv<o:p></o:p></span></p>
  </td>
 </tr>
</table>
<br><br>



<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>
<br>
<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=304 valign=top style='width:182.6pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><br><img src="image001.jpg"></p>
  </td>
  <td width=617 valign=top style='width:370.15pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;border-left:none;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>TUVISION TELECABLE<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>MARLA SANTAELLA
  RODRIGUEZ<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>SARM800402837<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>CALLE VENUSTIANO
  CARRANZA, SN. COL CENTRO<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>SANTA MARIA
  ZACATEPEC<o:p></o:p></span></p>
  <p class=MsoNormal align=right style='text-align:right;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>OAXACA</span></p>
  </td>
 </tr>
</table>

<br><br>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=921 colspan=3 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><b>LA PRESENTE CARATULA Y EL CONTRATO DE
  ADHESION SE ENCUENTRAN DISPONIBLES EN</b><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width=307 valign=top style='width:184.25pt;border-top:none;border-left:
  solid black 1.0pt;mso-border-left-themecolor:text1;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;border-right:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>1. La página del
  proveedor<o:p></o:p></span></p>
  </td>
  <td width=614 colspan=2 valign=top style='width:368.5pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-bottom-alt:solid black .5pt;mso-border-bottom-themecolor:text1;
  mso-border-right-alt:solid black .5pt;mso-border-right-themecolor:text1;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>www.tuvision.tv<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=307 valign=top style='width:184.25pt;border-top:none;border-left:
  solid black 1.0pt;mso-border-left-themecolor:text1;border-bottom:solid black 1.0pt;
  mso-border-bottom-themecolor:text1;border-right:none;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-left-alt:solid black .5pt;
  mso-border-left-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;background:#F2F2F2;mso-background-themecolor:
  background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>2. Buró comercial de
  PROFECO<o:p></o:p></span></p>
  </td>
  <td width=614 colspan=2 valign=top style='width:368.5pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:
  text1;border-right:solid black 1.0pt;mso-border-right-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-bottom-alt:solid black .5pt;mso-border-bottom-themecolor:text1;
  mso-border-right-alt:solid black .5pt;mso-border-right-themecolor:text1;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>https://burocomercial.profeco.gob.mx<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;mso-yfti-lastrow:yes'>
  <td width=458 colspan=2 valign=top style='width:274.75pt;border-top:none;
  border-left:solid black 1.0pt;mso-border-left-themecolor:text1;border-bottom:
  solid black 1.0pt;mso-border-bottom-themecolor:text1;border-right:none;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-top-alt:solid black .5pt;mso-border-top-themecolor:text1;
  mso-border-left-alt:solid black .5pt;mso-border-left-themecolor:text1;
  mso-border-bottom-alt:solid black .5pt;mso-border-bottom-themecolor:text1;
  background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:
  242;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>3. Físicamente en
  los centros de atención del proveedor<o:p></o:p></span></p>
  </td>
  <td width=463 valign=top style='width:278.0pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;mso-border-bottom-themecolor:text1;
  border-right:solid black 1.0pt;mso-border-right-themecolor:text1;mso-border-top-alt:
  solid black .5pt;mso-border-top-themecolor:text1;mso-border-top-alt:solid black .5pt;
  mso-border-top-themecolor:text1;mso-border-bottom-alt:solid black .5pt;
  mso-border-bottom-themecolor:text1;mso-border-right-alt:solid black .5pt;
  mso-border-right-themecolor:text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Consultar centros de
  atención a clientes en www.tuvision.tv<o:p></o:p></span></p>
  </td>
 </tr>
 <![if !supportMisalignedColumns]>
 <tr height=0>
  <td width=241 style='border:none'></td>
  <td width=117 style='border:none'></td>
  <td width=389 style='border:none'></td>
 </tr>
 <![endif]>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=921 valign=top style='width:552.75pt;border:solid black 1.0pt;
  mso-border-themecolor:text1;mso-border-alt:solid black .5pt;mso-border-themecolor:
  text1;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'>LA PRESENTE CARÁTULA SE RIGE CONFORME A LAS CLÁUSULAS
  DEL CONTRATO DE ADHESIÓN REGISTRADO EN PROFECO EL 23/08/2019, CON NÚMERO: 213
  DISPONIBLE EN EL SIGUIENTE CÓDIGO<o:p></o:p></span></b></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal style='line-height:normal'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif"'><img src="qr.jpg" width="10%"><o:p></o:p></span></b></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal align=left style='text-align:left;line-height:normal'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal style='line-height:normal'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal style='line-height:normal'><b style='mso-bidi-font-weight:
  normal'>LAS FIRMAS INSERTAS ABAJO SON LA ACEPTACIÓN DE LA PRESENTE CARÁTULA Y
  CLAUSULADO DEL CONTRATO CON NÚMERO <?php echo $nocontrato;?></b></p>
  </td>
 </tr>
</table>

<p class=MsoNormal align=left style='text-align:left'><o:p>&nbsp;</o:p></p>

<p class=MsoNormal>Este contrato se firmó por duplicado en la Ciudad de <?php echo $sucursal;?>
 a <?php $fechaentera=strtotime($fecha_contrato); echo date("d",$fechaentera); echo " DE "; echo date("m",$fechaentera); echo " DE "; echo date("Y",$fechaentera);  ?> </p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=461 valign=top style='width:276.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
<br><br><br><br><br>
  <p class=MsoNormal style='line-height:normal'><img src="firma-marla.jpg" width="40%"></p>
  <p class=MsoNormal style='line-height:normal'>CONCESIONARIO</p>
  </td>
  <td width=461 valign=top style='width:276.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='line-height:normal'><?php echo "  <img src=http://tuvisiontelecable.com.mx/api/public/storage/upload/".$id_cliente.".jpg height='150pt''>";  ?><br>
            <?php echo $nombre." ".$paterno." ".$materno; ?></p>
  <p class=MsoNormal style='line-height:normal'>CLIENTE Y/O SUSCRIPTOR</p>
  </td>
 </tr>
</table>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</body>

</html>
