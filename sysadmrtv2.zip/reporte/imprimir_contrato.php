<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 12">
<meta name=Originator content="Microsoft Word 12">
<link rel=File-List href="contratoOK_archivos/filelist.xml">
<link rel=Edit-Time-Data href="contratoOK_archivos/editdata.mso">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>Microsoft</o:Author>
  <o:LastAuthor>Microsoft</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>16</o:TotalTime>
  <o:Created>2019-09-04T00:18:00Z</o:Created>
  <o:LastSaved>2019-09-04T00:18:00Z</o:LastSaved>
  <o:Pages>4</o:Pages>
  <o:Words>3322</o:Words>
  <o:Characters>18275</o:Characters>
  <o:Company>Microsoft</o:Company>
  <o:Lines>152</o:Lines>
  <o:Paragraphs>43</o:Paragraphs>
  <o:CharactersWithSpaces>21554</o:CharactersWithSpaces>
  <o:Version>12.00</o:Version>
 </o:DocumentProperties>
</xml><![endif]-->
<link rel=themeData href="contratoOK_archivos/themedata.thmx">
<link rel=colorSchemeMapping href="contratoOK_archivos/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:HyphenationZone>21</w:HyphenationZone>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>ES-MX</w:LidThemeOther>
  <w:LidThemeAsian>X-NONE</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:DontVertAlignCellWithSp/>
   <w:DontBreakConstrainedForcedTables/>
   <w:DontVertAlignInTxbx/>
   <w:Word11KerningPairs/>
   <w:CachedColBalance/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="--"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="true"
  DefSemiHidden="true" DefQFormat="false" DefPriority="99"
  LatentStyleCount="267">
  <w:LsdException Locked="false" Priority="0" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 9"/>
  <w:LsdException Locked="false" Priority="35" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" Priority="10" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" Priority="11" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" Priority="22" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" Priority="59" SemiHidden="false"
   UnhideWhenUsed="false" Name="Table Grid"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" QFormat="true" Name="TOC Heading"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;
	mso-font-charset:2;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:0 268435456 0 0 -2147483648 0;}
@font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;
	mso-font-charset:1;
	mso-generic-font-family:roman;
	mso-font-format:other;
	mso-font-pitch:variable;
	mso-font-signature:0 0 0 0 0 0;}
@font-face
	{font-family:"Arial Unicode MS";
	panose-1:2 11 6 4 2 2 2 2 2 4;
	mso-font-charset:128;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-134238209 -371195905 63 0 4129279 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-536859905 -1073732485 9 0 511 0;}
@font-face
	{font-family:"Helvetica Neue";
	mso-font-alt:"Times New Roman";
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:auto;
	mso-font-signature:0 0 0 0 0 0;}
@font-face
	{font-family:"\@Arial Unicode MS";
	panose-1:2 11 6 4 2 2 2 2 2 4;
	mso-font-charset:128;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-134238209 -371195905 63 0 4129279 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
span.MsoCommentReference
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:blue;
	mso-themecolor:hyperlink;
	text-decoration:underline;
	text-underline:single;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-noshow:yes;
	mso-style-priority:99;
	color:purple;
	mso-themecolor:followedhyperlink;
	text-decoration:underline;
	text-underline:single;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:36.0pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:36.0pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.Body, li.Body, div.Body
	{mso-style-name:Body;
	mso-style-unhide:no;
	mso-style-parent:"";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Helvetica Neue","serif";
	mso-fareast-font-family:"Arial Unicode MS";
	mso-bidi-font-family:"Arial Unicode MS";
	color:black;
	border:none;
	mso-ansi-language:ES-TRAD;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
.MsoPapDefault
	{mso-style-type:export-only;
	text-align:center;
	line-height:115%;}

@page{
  
  margin:0mm;
  size:Letter;
}
@media print{
  size: Letter portrait;
}

@page Section1
	{size:612.0pt 792.0pt;
	margin:14.2pt 37.9pt 42.55pt 42.55pt;
	mso-header-margin:35.4pt;
	mso-footer-margin:35.4pt;
	mso-paper-source:0;
  }
div.Section1
	{page:Section1;}
 /* List Definitions */
 @list l0
	{mso-list-id:160121884;
	mso-list-type:hybrid;
	mso-list-template-ids:803119898 134873103 134873113 134873115 134873103 134873113 134873115 134873103 134873113 134873115;}
@list l0:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l0:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l1
	{mso-list-id:638846351;
	mso-list-type:hybrid;
	mso-list-template-ids:1278539238 134873089 134873091 134873093 134873089 134873091 134873093 134873089 134873091 134873093;}
@list l1:level1
	{mso-level-number-format:bullet;
	mso-level-text:;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l2
	{mso-list-id:828638975;
	mso-list-type:hybrid;
	mso-list-template-ids:1473271062 -1232592254 134873113 134873115 134873103 134873113 134873115 134873103 134873113 134873115;}
@list l2:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	mso-ansi-font-weight:bold;}
@list l3
	{mso-list-id:1417052013;
	mso-list-type:hybrid;
	mso-list-template-ids:2125118640 1489533106 134873113 134873115 134873103 134873113 134873115 134873103 134873113 134873115;}
@list l3:level1
	{mso-level-number-format:alpha-lower;
	mso-level-text:"%1\)";
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	mso-ansi-font-weight:bold;}
@list l4
	{mso-list-id:1450513950;
	mso-list-type:hybrid;
	mso-list-template-ids:-818391484 -823348860 134873113 134873115 134873103 134873113 134873115 134873103 134873113 134873115;}
@list l4:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	mso-ansi-font-weight:bold;}
@list l5
	{mso-list-id:1573735235;
	mso-list-type:hybrid;
	mso-list-template-ids:1616412846 257184380 134873113 134873115 134873103 134873113 134873115 134873103 134873113 134873115;}
@list l5:level1
	{mso-level-number-format:alpha-lower;
	mso-level-text:"%1\)";
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	mso-hansi-font-family:"Arial Unicode MS";
	font-variant:normal !important;
	color:black;
	text-transform:none;
	position:relative;
	top:0pt;
	mso-text-raise:0pt;
	letter-spacing:0pt;
	mso-font-width:100%;
	mso-font-kerning:0pt;
	mso-ansi-font-weight:bold;
	text-decoration:none;
	text-line-through:none;
	vertical-align:baseline;}
@list l6
	{mso-list-id:2040742668;
	mso-list-type:hybrid;
	mso-list-template-ids:-1017602972 1246688244 134873113 134873115 134873103 134873113 134873115 134873103 134873113 134873115;}
@list l6:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	mso-ansi-font-weight:bold;}
@list l6:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Tabla normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-qformat:yes;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
table.MsoTableGrid
	{mso-style-name:"Tabla con cuadrícula";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-priority:59;
	mso-style-unhide:no;
	border:solid black 1.0pt;
	mso-border-themecolor:text1;
	mso-border-alt:solid black .5pt;
	mso-border-themecolor:text1;
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-border-insideh:.5pt solid black;
	mso-border-insideh-themecolor:text1;
	mso-border-insidev:.5pt solid black;
	mso-border-insidev-themecolor:text1;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="5122"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=ES-MX link=blue vlink=purple style='tab-interval:35.4pt'>

<div class=Section1>
<br><br>
<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=281 valign=top style='width:168.45pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><!--[if gte vml 1]><v:shapetype
   id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
   path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Imagen_x0020_3" o:spid="_x0000_s1029" type="#_x0000_t75"
   alt="TVLOG1" style='position:absolute;left:0;text-align:left;margin-left:27.95pt;
   margin-top:10.35pt;width:115.5pt;height:31.8pt;z-index:1;visibility:visible;
   mso-wrap-style:square;mso-wrap-distance-left:9pt;mso-wrap-distance-top:0;
   mso-wrap-distance-right:9pt;mso-wrap-distance-bottom:0;
   mso-position-horizontal:absolute;mso-position-horizontal-relative:text;
   mso-position-vertical:absolute;mso-position-vertical-relative:text'>
   <v:imagedata src="contratoOK_archivos/image001.jpg" o:title="TVLOG1"/>
  </v:shape><![endif]--><![if !vml]><span style='mso-ignore:vglayout;
  position:absolute;z-index:1;left:0px;margin-left:37px;margin-top:14px;
  width:154px;height:42px'><img width=154 height=42
  src="image002.jpg" alt=TVLOG1 v:shapes="Imagen_x0020_3"></span><![endif]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>
  </td>
  <td width=617 valign=top style='width:370.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>TU VISION TELECABLE<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>MARLA SANTAELLA RODRIGUEZ<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>CALLE VENUSTIANO CARRANZA, SN COL CENTRO, SANTA
  MARIA, ZACATEPEC, OAXACA, CP 71050. RFC. SARM800402837<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span lang=EN-US style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt;mso-ansi-language:EN-US'>TEL. 9993306039<span
  style='mso-spacerun:yes'>   </span></span><a href="http://WWW.TUVISION.TV"><span
  lang=EN-US style='font-size:8.0pt;mso-bidi-font-size:11.0pt;mso-ansi-language:
  EN-US'>WWW.TUVISION.TV</span></a><span lang=EN-US style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt;mso-ansi-language:EN-US'><span
  style='mso-spacerun:yes'>  </span>CONTACTO@TUVISION.TV</span><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>
  </td>
 </tr>
</table>

<p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
.0001pt;mso-add-space:auto;text-align:center;line-height:normal;mso-layout-grid-align:
none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>CONTRATO
DE PRESTACIÓN DE SERVICIO DE TELEVISIÓN DE PAGA QUE CELEBRA POR UNA PARTE EL
PROVEEDOR Y POR OTRA PARTE EL SUSCRIPTOR, AL TENOR DE LO SIGUIENTE.<o:p></o:p></span></b></p>

<p class=MsoListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
.0001pt;mso-add-space:auto;text-align:center;line-height:normal;mso-layout-grid-align:
none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>DECLARACIONE</span></b><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>S<o:p></o:p></span></b></p>

<p class=MsoListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
.0001pt;mso-add-space:auto;text-align:center;line-height:normal;mso-layout-grid-align:
none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;margin-bottom:.0001pt;
mso-add-space:auto;text-align:justify;text-indent:-18.0pt;line-height:normal;
mso-list:l0 level1 lfo1;mso-layout-grid-align:none;punctuation-wrap:simple;
text-autospace:none;vertical-align:baseline'><![if !supportLists]><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
ES-TRAD;mso-fareast-language:ES'><span style='mso-list:Ignore'>1.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><span
lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:
ES'>Ambas partes declaran:<b style='mso-bidi-font-weight:normal'><o:p></o:p></b></span></p>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
justify;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:simple;
text-autospace:none;vertical-align:baseline'><b style='mso-bidi-font-weight:
normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:
ES'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:54.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-align:justify;text-indent:-18.0pt;line-height:normal;mso-list:l3 level1 lfo2;
mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:none;
vertical-align:baseline'><![if !supportLists]><b style='mso-bidi-font-weight:
normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-ansi-language:ES-TRAD;mso-fareast-language:
ES'><span style='mso-list:Ignore'>a)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>Que los datos consistentes
en el domicilio, RFC y datos de localización del domicilio son ciertos yse
encuentran establecidos en la carátula del presente contrato.<b
style='mso-bidi-font-weight:normal'><o:p></o:p></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:54.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-align:justify;text-indent:-18.0pt;line-height:normal;mso-list:l3 level1 lfo2;
mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:none;
vertical-align:baseline'><![if !supportLists]><b style='mso-bidi-font-weight:
normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-ansi-language:ES-TRAD;mso-fareast-language:
ES'><span style='mso-list:Ignore'>b)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>Que tienen pleno goce de sus
derechos y capacidad legal para contratar y obligarse en términos del presente
contrato.<b style='mso-bidi-font-weight:normal'><o:p></o:p></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:5.05pt;margin-left:54.0pt;mso-add-space:auto;text-align:justify;
text-indent:-18.0pt;line-height:normal;mso-list:l3 level1 lfo2;background:white'><![if !supportLists]><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
ES-TRAD;mso-fareast-language:ES'><span style='mso-list:Ignore'>c)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><span
style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
"Times New Roman";mso-fareast-language:ES-MX'>Que aceptan que el presente
contrato se regirá por la Ley Federal de Protección al Consumidor, Ley Federal
de Telecomunicaciones y Radiodifusión, la Norma Oficial Mexicana
NOM-184-SCFI-2018, <i style='mso-bidi-font-style:normal'>Elementos Normativos y
Obligaciones Específicas que deben Observar los Proveedores para la
Comercialización y/o Prestación de los Servicios de Telecomunicaciones cuando
Utilicen una Red Pública de Telecomunicaciones</i>, y demás normatividad
aplicable, por lo que los derechos y obligaciones establecidas en dicho marco
normativo se tendrán por aquí reproducidas como si a la letra se insertase.</span><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:5.05pt;margin-left:54.0pt;mso-add-space:auto;text-align:justify;
text-indent:-18.0pt;line-height:normal;mso-list:l3 level1 lfo2;background:white'><![if !supportLists]><b
style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'><span style='mso-list:Ignore'>d)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><span
style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Que la manifestación
de la voluntad para adherirse al presente contrato de adhesión y su<span
style='mso-spacerun:yes'>  </span>carátula (la cual forma parte integrante del
referido contrato)son las firmas que plasmen<span style='mso-spacerun:yes'> 
</span>las partes<span style='mso-spacerun:yes'>  </span>en la carátula. <o:p></o:p></span></p>

<p class=MsoListParagraphCxSpLast style='margin-top:0cm;margin-right:0cm;
margin-bottom:5.05pt;margin-left:54.0pt;mso-add-space:auto;text-align:justify;
text-indent:-18.0pt;line-height:normal;mso-list:l3 level1 lfo2;background:white'><![if !supportLists]><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
ES-TRAD;mso-fareast-language:ES'><span style='mso-list:Ignore'>e)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><span
lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:
ES'>Que es<span style='mso-spacerun:yes'>  </span>su voluntad celebrar el
presente contrato sujetándose a las siguientes:<b style='mso-bidi-font-weight:
normal'><o:p></o:p></b></span></p>

<p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
text-align:center;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:
simple;text-autospace:none;vertical-align:baseline'><b style='mso-bidi-font-weight:
normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:"Times New Roman";letter-spacing:2.0pt;mso-ansi-language:
ES-TRAD;mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
text-align:center;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:
simple;text-autospace:none;vertical-align:baseline'><b style='mso-bidi-font-weight:
normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:"Times New Roman";letter-spacing:2.0pt;mso-ansi-language:
ES-TRAD;mso-fareast-language:ES'>CLÁUSULA</span></b><b style='mso-bidi-font-weight:
normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:
ES'>S<o:p></o:p></span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></b></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=446 valign=top style='width:267.65pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>PRIMERA: OBJETO DEL
  CONTRATO.</span></b><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES'>El PROVEEDOR se obliga a prestar el servicio
  de Televisión de Paga, (en adelante el Servicio), de manera continua,
  uniforme, regular yeficiente,a cambio del pagode la tarifa, plan o paquete
  que el SUSCRIPTORhaya seleccionado en la carátula del presente contrato.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>El PROVEEDOR se obliga a prestar el SERVICIO de
  acuerdo a los índices y parámetros de calidad que establezca el Instituto
  Federal de Telecomunicaciones (en adelante IFT)<span
  style='mso-spacerun:yes'>  </span>o, en su caso los ofrecidos implícitamente
  o contratados los cuales<span style='mso-spacerun:yes'>  </span>no pueden ser
  menores a los que establezca el IFT<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>El presente contrato <b style='mso-bidi-font-weight:
  normal'>se regirá bajo el esquema de mensualidades fijas POR ADELANTADO</b>,
  es decir se va a pagar el servicio de manera previa a utilizarlo, dicho
  esquema va a operar<b style='mso-bidi-font-weight:normal'> bajo los términos
  y condiciones del<span style='mso-spacerun:yes'>  </span>pospago exceptuando
  el momento de pago del servicio</b>. </span><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:ES-MX'>Cualquier cargo por el </span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>SERVICIO</span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'> comienza a partir de la fecha
  en&nbsp;la que efectivamente el PROVEEDOR inicie la prestación del SERVICIO.</span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>El PROVEEDOR es el único responsable</span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>frente al SUSCRIPTOR
  por</span><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'> la prestación del SERVICIO, así como, de los bienes
  o servicios adicionales contratados.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Todo
  lo pactado o contratadoentre el SUSCRIPTOR y el PROVEEDOR<span
  style='mso-spacerun:yes'>  </span>de manera verbal o electrónica se le
  debeconfirmarpor escrito al SUSCRIPTOR a través del medio que él elija, en un
  plazo máximo de cinco días hábiles, contados a partir del momento en que se
  realice el pacto o contratación.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal'><b style='mso-bidi-font-weight:normal'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>SEGUNDA:VIGENCIA. </span></b><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>Este
  contrato <b style='mso-bidi-font-weight:normal'>NOobliga a un plazo forzoso</b>,
  por lo que al tener una vigencia indeterminadael SUSCRIPTOR puede darlo por
  terminado en cualquier momento, <b style='mso-bidi-font-weight:normal'>SIN
  penalidad alguna</b> y sin necesidad de recabar autorización del PROVEEDOR,
  únicamente se tendrá que dar aviso a este últimoa </span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>través
  del mismo medio en el cual contrató el servicio o</span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>por los
  medios de contacto señalados en la carátula.<b style='mso-bidi-font-weight:
  normal'><o:p></o:p></b></span></p>
  </td>
  <td width=449 valign=top style='width:269.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>TERCERA:EQUIPO TERMINAL.</span></b><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'> Los equipos y accesorios que son necesarios para
  recibir el SERVICIO son propiedad del PROVEEDOR mismos que se entreganal
  SUSCRIPTOR en <b style='mso-bidi-font-weight:normal'>COMODATO</b> (en
  préstamo). El SUSCRIPTOR<span style='mso-spacerun:yes'>  </span><span
  style='mso-bidi-font-weight:bold'>se<span style='mso-spacerun:yes'> 
  </span>compromete a la guarda, custodia y conservación del (los) equipo(s),
  durante todo el tiempo que se encuentre en su poder, hasta la terminación del
  presente contrato y deberán ser devueltos a</span>l PROVEEDOR, presentando
  únicamente el desgaste natural por el paso del tiempo, y por su parte el PROVEEDOR
  se obliga a dar mantenimiento a los equipos y accesorios para la adecuada
  prestación del SERVICIO.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>Cuando las fallasque se presenten en el equipo y
  accesorios no sean atribuibles al SUSCRIPTOR,el PROVEEDOR se obliga a
  realizar de manera gratuitalas reparaciones necesarias, en tanto este
  contrato permanezca vigente. Ambas partes deberán coordinarsepara establecer
  la fecha y hora en que se llevarán a cabodichas actividades. El personal
  designado por el PROVEEDOR se debe de identificar y mostrar al SUSCRIPTOR la
  orden de trabajo expedida por el PROVEEDOR.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES'>En caso de que el equipo terminal
  se encuentre en reparación o mantenimiento, el PROVEEDOR debe suspender el
  cobro del SERVICIO por el periodo que dure la revisión, reparación y/o
  mantenimiento de dicho equipo terminal, excepto cuando el PROVEEDOR acredite
  que el SUSCRIPTOR está haciendo uso del servicio o le haya proporcionado un
  equipo sustituto.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>Cuando el Equipo provisto
  en comodato,<span style='mso-spacerun:yes'>  </span>sea robado o sea objeto
  de algún siniestro, el SUSCRIPTOR deberá dar aviso inmediato al PROVEEDOR, en
  un plazo que no excederá de veinticuatro horas posteriores al evento para la
  reposición del Equipoy para suspender el cobro del SERVICIO hasta que el
  SUSCRIPTOR tenga otro equipo para poder recibir el SERVICIO.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraph style='margin:0cm;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;line-height:normal;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>El SUSCRIPTOR tendrá un plazo de 30 días hábiles
  posteriores al robo o siniestro para presentar copia certificada de la
  constancia correspondiente levantada ante una Autoridad<b style='mso-bidi-font-weight:
  normal'><o:p></o:p></b></span></p>
  </td>
 </tr>
</table>
<br><br><br><br><br><br>

<p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></b></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=281 valign=top style='width:168.45pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><!--[if gte vml 1]><v:shape
   id="_x0000_s1028" type="#_x0000_t75" alt="TVLOG1" style='position:absolute;
   left:0;text-align:left;margin-left:27.95pt;margin-top:10.35pt;width:115.5pt;
   height:31.8pt;z-index:2;visibility:visible;mso-wrap-style:square;
   mso-wrap-distance-left:9pt;mso-wrap-distance-top:0;
   mso-wrap-distance-right:9pt;mso-wrap-distance-bottom:0;
   mso-position-horizontal:absolute;mso-position-horizontal-relative:text;
   mso-position-vertical:absolute;mso-position-vertical-relative:text'>
   <v:imagedata src="contratoOK_archivos/image001.jpg" o:title="TVLOG1"/>
  </v:shape><![endif]--><![if !vml]><span style='mso-ignore:vglayout;
  position:absolute;z-index:2;left:0px;margin-left:37px;margin-top:14px;
  width:154px;height:42px'><img width=154 height=42
  src="image002.jpg" alt=TVLOG1 v:shapes="_x0000_s1028"></span><![endif]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>
  </td>
  <td width=617 valign=top style='width:370.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>TU VISION TELECABLE<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>MARLA SANTAELLA RODRIGUEZ<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>CALLE VENUSTIANO CARRANZA, SN COL CENTRO, SANTA
  MARIA, ZACATEPEC, OAXACA, CP 71050. RFC. SARM800402837<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span lang=EN-US style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt;mso-ansi-language:EN-US'>TEL. 9993306039<span
  style='mso-spacerun:yes'>   </span></span><a href="http://WWW.TUVISION.TV"><span
  lang=EN-US style='font-size:8.0pt;mso-bidi-font-size:11.0pt;mso-ansi-language:
  EN-US'>WWW.TUVISION.TV</span></a><span lang=EN-US style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt;mso-ansi-language:EN-US'><span
  style='mso-spacerun:yes'>  </span>CONTACTO@TUVISION.TV</span><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-bottom-alt:solid windowtext .5pt;
 mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;mso-border-insideh:
 none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=449 valign=top style='width:269.25pt;border:none;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>Competente, que acredite el objeto de robo o
  siniestropara que no tenga costo la reposición del equipo.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  ES-MX'>CUARTA:</span></b><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>La entrega e instalación
  del equipo terminal no podrá ser mayor a 10 días hábiles a partir de la firma
  del presente contrato. <o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>En caso de que el PROVEEDOR no
  pueda iniciar la prestación del servicio por causas atribuibles a él</span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'> por imposibilidad física o técnica para la
  instalación del equipo</span><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>, debe
  devolver al SUSCRIPTOR las cantidades que haya pagado por concepto de anticipo,
  en un plazo no mayor de 30 días hábiles siguientes a la fecha límite
  establecida para la instalación, y se tendrá por terminado el contrato de
  adhesión sin responsabilidad para el SUSCRIPTOR debiendo pagar el PROVEEDOR,
  una penalidad equivalente al 20% de las cantidades que haya recibido por
  concepto de anticipo, por su incumplimiento en los casos atribuibles a él.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>El </span><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  ES-MX'>SUSCRIPTOR</span><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES'> puede negarse, sin responsabilidad alguna
  para él, a la instalación o activación del servicio ante la negativa del personal
  del </span><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>PROVEEDOR</span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'> a identificarse y/o a mostrar la orden de trabajo.
  Situación que debe informar al </span><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:ES-MX'>PROVEEDOR</span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES'> en ese
  momento.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>QUINTA:</span></b><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  Calibri;mso-fareast-language:ES-MX'>Las tarifas del servicio se encuentran
  inscritas&nbsp; en el Registro Público de Concesiones del IFT</span><b><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  Calibri;background:white'> y </span></b><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Calibri'>pueden ser
  consultadas </span><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Calibri;mso-fareast-language:ES-MX'>en la página del
  IFT&nbsp; </span><a href="http://www.ift.org.mx"><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Calibri;color:blue;
  mso-fareast-language:ES-MX'>www.ift.org.mx</span></a><b><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  Calibri;color:black;background:white'>. <o:p></o:p></span></b></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  Calibri;color:black;background:white'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  Calibri;background:white;mso-bidi-font-weight:bold'>Las tarifas no podrán
  establecer condiciones contractuales tales como causas de&nbsp;terminación
  anticipada o cualquier otra condición que deba ser pactada dentro de los
  contratos de adhesión.&nbsp;De igual manera, no se podrán establecer términos
  y/o condiciones de aplicación de las tarifas que&nbsp;contravengan a lo
  establecido en el presente contrato de adhesión. </span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></p>
  <p class=MsoNormalCxSpFirst style='margin-bottom:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;punctuation-wrap:
  simple;text-autospace:none;vertical-align:baseline'><span style='font-size:
  9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:Calibri;
  mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormalCxSpLast style='margin-bottom:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;punctuation-wrap:
  simple;text-autospace:none;vertical-align:baseline'><span style='font-size:
  9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:Calibri;
  mso-fareast-language:ES-MX'>Los planes, paquetes, cobertura donde el
  PROVEEDOR puede prestar el servicio y tarifas se pueden consultar por los
  medios establecidos en la carátula del presente contrato.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  ES'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>SEXTA:</span></b><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'>SERVICIOS ADICIONALES.</span></b><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>El PROVEEDOR puede
  ofrecer servicios adicionales al SERVICIO originalmente contratado
  (Televisión de Paga)<span style='mso-spacerun:yes'>  </span>siempre y cuando
  sea acordado entre las partes y el SUSCRIPTOR lo solicite y autorice a través
  de medios físicos o electrónicos o digitales o de cualquier otra nueva
  tecnología que lo permita. El PROVEEDOR deberá contar con la opción de
  ofrecer al SUSCRIPTOR cada servicio adicional o producto por separado,
  debiendo dar a conocer el precio previamente a su contratación.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>El PROVEEDOR puede ofrecer planes o
  paquetes que incluyan los servicios y/o productos que considere convenientes,
  siempre y cuando tenga el consentimiento expreso del SUSCRIPTOR para tal
  efecto. Sin embargo no puede obligar al SUSCRIPTOR a contratar servicios
  adicionales como requisito para la contratación o continuación de la
  prestación del SERVICIO.<o:p></o:p></span></p>
  <p class=MsoListParagraph style='margin:0cm;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;line-height:normal;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES;mso-bidi-font-weight:bold'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal align=center style='text-align:center;line-height:normal'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES;mso-bidi-font-weight:bold'>El
  SUSCRIPTOR puede cancelar los servicios adicionales al SERVICIO originalmente
  contratadoen cualquier momento, por los medios señalados en la carátula para
  tales efectos, para lo que el PROVEEDOR tiene un plazo máximo de 5 días
  naturales a partir de dicha manifestación para cancelarlo, sin</span></p>
  </td>
  <td width=449 valign=top style='width:269.3pt;border:none;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES;mso-bidi-font-weight:bold'>que ello
  implique la suspensión o cancelación de la prestación del SERVICIO
  originalmente contratado. La cancelación de los Servicios adicionales al SERVICIO
  originalmente contratado no exime al SUSCRIPTOR del pago de las cantidades
  adeudadas por los servicios adicionales utilizados.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>SÉPTIMA: ESTADO DE CUENTA
  RECIBO Y/O FACTURA.</span></b><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'> El PROVEEDOR debe </span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>entregar&nbsp;gratuitamente en
  el domicilio del SUSCRIPTOR, con al menos 10 días naturales antes de la fecha
  de vencimiento del plazo para el pago del SERVICIO contratado, un estado de
  cuenta, recibo y/o factura el cual deberá de contener de manera desglosada la
  descripción de los cargos, costos, conceptos y naturaleza delSERVICIO y de
  los servicios adicionalescontratados.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>El </span><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  ES-MX'>SUSCRIPTOR puede pactar con el </span><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:ES;mso-bidi-font-weight:bold'>PROVEEDOR</span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'> para que, en sustitución de la
  obligación referida, pueda&nbsp;consultarse el citado estado de cuenta y/o
  factura, a través de cualquier medio físico o electrónico o digital o de
  cualquier otra nueva tecnología que lo permita y que al efecto se acuerde entre
  ambas partes.</span><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>La fecha, forma y lugares de pago</span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'> se pueden consultar por los
  medios señalados en la carátula del presente contrato.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES;mso-bidi-font-weight:bold'>Tratándose
  de cargos indebidos, el PROVEEDOR deberá efectuar la devolución
  correspondiente dentro</span><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'> de un plazo no mayor a
  los 5 días hábiles posteriores a la reclamación. Dicha devolución se
  efectuará por el mismo medio en el que se realizó el cargo indebido
  correspondiente y se deberá bonificar el 20% sobre el monto del cargo
  realizado indebidamente.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>OCTAVA: CONTROL
  PARENTAL. </span></b><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'>El PROVEEDOR deberá tener disponible
  para<span style='mso-spacerun:yes'>  </span>el </span><span style='font-size:
  9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:ES-MX'>SUSCRIPTOR</span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'> que
  lo solicite, el servicio de control parental (servicio útil para padres y
  responsables educativos que desean impedir que niños o adolescentes puedan
  acceder a determinados contenidos) de manera gratuitay publicar de forma
  clara las características operativas de este servicio y las instrucciones
  para que el SUSCRIPTOR pueda operar las aplicaciones necesarias para el
  correcto funcionamiento del mencionado servicio.<b style='mso-bidi-font-weight:
  normal'><o:p></o:p></b></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES'>NOVENA: MODIFICACIONES.</span></b><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>El PROVEEDOR dará aviso al </span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>SUSCRIPTOR</span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>, cuando menos con 15 días naturales de
  anticipación, de cualquier cambio en los términos y condiciones originalmente
  contratados. Dicho aviso deberá ser notificado, a través de medios físicos o
  electrónicos o digitales o de cualquier otra nueva tecnología que lo permita.<b
  style='mso-bidi-font-weight:normal'><o:p></o:p></b></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>En caso de que el SUSCRIPTOR no esté de acuerdo
  con el cambio de los términos y condiciones originalmente contratados, podrá
  optar por</span><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>exigir
  el cumplimiento forzoso del contrato bajo las condiciones en que se firmó el
  mismo, o</span><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>a </span><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  ES-MX'>solicitarla terminacióndel presente contrato sin penalidad alguna para
  el SUSCRIPTOR.</span><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'><o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>El PROVEEDOR deberá obtener el consentimiento del
  </span><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>SUSCRIPTOR</span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'> a través de medios físicos o electrónicos o
  digitales o de cualquier otra nueva tecnología que lo permita, para poder dar
  por terminado el presente contrato con la finalidad de sustituirlo por otro,
  o bien para la modificación de sus términos y condiciones. No se requerirá
  dicho consentimiento cuando la modificación genere un beneficio en favor del </span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>SUSCRIPTOR.</span></p>
  </td>
 </tr>
</table>
<br><br>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=281 valign=top style='width:168.45pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><!--[if gte vml 1]><v:shape
   id="_x0000_s1028" type="#_x0000_t75" alt="TVLOG1" style='position:absolute;
   left:0;text-align:left;margin-left:27.95pt;margin-top:10.35pt;width:115.5pt;
   height:31.8pt;z-index:2;visibility:visible;mso-wrap-style:square;
   mso-wrap-distance-left:9pt;mso-wrap-distance-top:0;
   mso-wrap-distance-right:9pt;mso-wrap-distance-bottom:0;
   mso-position-horizontal:absolute;mso-position-horizontal-relative:text;
   mso-position-vertical:absolute;mso-position-vertical-relative:text'>
   <v:imagedata src="contratoOK_archivos/image001.jpg" o:title="TVLOG1"/>
  </v:shape><![endif]--><![if !vml]><span style='mso-ignore:vglayout;
  position:absolute;z-index:2;left:0px;margin-left:37px;margin-top:14px;
  width:154px;height:42px'><img width=154 height=42
  src="image002.jpg" alt=TVLOG1 v:shapes="_x0000_s1028"></span><![endif]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>
  </td>
  <td width=617 valign=top style='width:370.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>TU VISION TELECABLE<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>MARLA SANTAELLA RODRIGUEZ<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>CALLE VENUSTIANO CARRANZA, SN COL CENTRO, SANTA
  MARIA, ZACATEPEC, OAXACA, CP 71050. RFC. SARM800402837<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span lang=EN-US style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt;mso-ansi-language:EN-US'>TEL. 9993306039<span
  style='mso-spacerun:yes'>   </span></span><a href="http://WWW.TUVISION.TV"><span
  lang=EN-US style='font-size:8.0pt;mso-bidi-font-size:11.0pt;mso-ansi-language:
  EN-US'>WWW.TUVISION.TV</span></a><span lang=EN-US style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt;mso-ansi-language:EN-US'><span
  style='mso-spacerun:yes'>  </span>CONTACTO@TUVISION.TV</span><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>
  </td>
 </tr>
</table>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=449 valign=top style='width:269.25pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>El SUSCRIPTOR</span><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:ES-MX;mso-bidi-font-weight:bold'> puede cambiar de
  tarifa, paquete o plan, aunque sea de menor monto con el que se contrató, en
  cualquier momento, pagando en su caso los cargos adicionales que se generen
  asociados a este cambio.</span><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'><o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>DÉCIMA: SUSPENSIÓN DEL
  SERVICIO</span></b><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'>. El PROVEEDOR podrá suspender el
  Servicio, previa notificación por escrito al SUSCRIPTOR, si este último
  incurre en cualquiera de los siguientes supuestos:<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;tab-stops:46.7pt;
  mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:none;
  vertical-align:baseline'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><span style='mso-tab-count:
  1'>                    </span><o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:17.85pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;text-indent:-17.85pt;line-height:normal;mso-list:
  l6 level1 lfo3;mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:
  none;vertical-align:baseline'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-ansi-language:ES-TRAD;mso-fareast-language:
  ES-MX'><span style='mso-list:Ignore'>1.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>Por pagos parciales de
  la tarifa aplicable al SERVICIO.<o:p></o:p></span></p>
  
  <p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:
  0cm;margin-bottom:10.0pt;margin-left:17.85pt;mso-add-space:auto;text-align:
  justify;text-indent:-17.85pt;line-height:normal;mso-list:l6 level1 lfo3;
  mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:none;
  vertical-align:baseline'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-ansi-language:ES-TRAD;mso-fareast-language:
  ES-MX'><span style='mso-list:Ignore'>2.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>Por falta de pago del SERVICIOdespués
  de 5 días naturales posteriores a la fecha de pago señalada en la carátula
  del presente contrato.<o:p></o:p></span></p>
  
  <p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:17.85pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;text-indent:-17.85pt;line-height:normal;mso-list:
  l6 level1 lfo3;mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:
  none;vertical-align:baseline'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-ansi-language:ES-TRAD;mso-fareast-language:
  ES-MX'><span style='mso-list:Ignore'>3.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>Por utilizar el
  servicio de manera contraria a lo previsto en el contrato y/o a las
  disposiciones aplicables en materia de telecomunicaciones.<o:p></o:p></span></p>
  
  <p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:17.85pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;text-indent:-17.85pt;line-height:normal;mso-list:
  l6 level1 lfo3;mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:
  none;vertical-align:baseline'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-ansi-language:ES-TRAD;mso-fareast-language:
  ES-MX'><span style='mso-list:Ignore'>4.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>Por alterar, modificar
  o mover el equipo terminal.<o:p></o:p></span></p>
  
  <p class=MsoListParagraphCxSpLast style='margin-top:12.0pt;margin-right:0cm;
  margin-bottom:0cm;margin-left:17.85pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;text-indent:-17.85pt;line-height:normal;mso-list:
  l6 level1 lfo3;mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:
  none;vertical-align:baseline'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-ansi-language:ES-TRAD;mso-fareast-language:
  ES-MX'><span style='mso-list:Ignore'>5.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>Por declaración
  judicial o administrativa.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline'><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline'><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>Una
  vez solucionada la causa que originó la suspensión del servicio, el PROVEEDOR
  deberá reanudar la prestación del servicio en un periodo máximo de 48 horas,
  debiendo pagar EL SUSCRIPTORlos pagos de reconexión, el cual no podrá ser
  superior al 20% del pago de una mensualidad.<o:p></o:p></span></p>
  <p class=MsoListParagraph style='margin:0cm;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;line-height:normal;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>DÉCIMA PRIMERA:
  CONTINUIDAD DEL SERVICIO Y BONIFICACIONES POR INTERRUPCIÓN.</span></b><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>El proveedor deberá bonificar y compensar al
  suscriptor en los siguientes casos:<b style='mso-bidi-font-weight:normal'><o:p></o:p></b></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></b></p>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:7.1pt;margin-bottom:.0001pt;mso-add-space:auto;
  text-align:justify;text-indent:-7.1pt;line-height:normal;mso-list:l2 level1 lfo4;
  mso-hyphenate:none;tab-stops:7.1pt 14.2pt;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><![if !supportLists]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'><span style='mso-list:Ignore'>1.</span></span></b><![endif]><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>Cuando <b style='mso-bidi-font-weight:normal'>porcausas
  atribuibles a el PROVEEDOR </b>no se preste el servicio de telecomunicaciones
  en la forma y términos convenidos, contratados, ofrecidos o implícitos o
  información desplegada en la publicidad del proveedor, así como con los
  índices y parámetros de calidad contratados o establecidos por el IFT,éste
  debe de compensar al consumidor la parte proporcional del precio del
  servicio, plan o paquete que se dejó de prestar y como bonificación al menos
  el 20% del monto del periodo de afectación de la prestación del servicio.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:7.1pt;margin-bottom:.0001pt;mso-add-space:auto;
  text-align:justify;line-height:normal;mso-hyphenate:none;tab-stops:7.1pt 14.2pt;
  mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:none;
  vertical-align:baseline'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:
  0cm;margin-bottom:10.0pt;margin-left:7.1pt;mso-add-space:auto;text-align:
  justify;text-indent:-7.1pt;line-height:normal;mso-list:l2 level1 lfo4;
  mso-hyphenate:none;tab-stops:14.2pt;mso-layout-grid-align:none;punctuation-wrap:
  simple;text-autospace:none;vertical-align:baseline'><![if !supportLists]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'><span style='mso-list:Ignore'>2.</span></span></b><![endif]><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>Cuando la interrupción del servicio sea <b
  style='mso-bidi-font-weight:normal'>por casos fortuitos o de fuerza mayor</b>,
  si la misma dura más de 24 horas consecutivas siguientes al reporte que
  realice el SUSCRIPTOR,el PROVEEDOR hará la compensación por la parte
  proporcional del periodo en que se dejó de prestar el servicio contratado, la
  cual se verá reflejada en el siguiente recibo y/o factura.Además, el
  PROVEEDOR deberá bonificar por lo menos el 20% del monto del periodo de
  afectación. <o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:7.1pt;margin-bottom:.0001pt;mso-add-space:auto;
  text-align:justify;line-height:normal;mso-hyphenate:none;tab-stops:14.2pt;
  mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:none;
  vertical-align:baseline'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:7.1pt;margin-bottom:.0001pt;mso-add-space:auto;
  text-align:justify;text-indent:-7.1pt;line-height:normal;mso-list:l2 level1 lfo4;
  tab-stops:14.2pt;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline'><![if !supportLists]><b><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-ansi-language:ES-TRAD;mso-fareast-language:
  ES'><span style='mso-list:Ignore'>3.</span></span></b><![endif]><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES;mso-bidi-font-weight:bold'>Cuando se interrumpa el
  servicio por alguna <b>causa previsible</b> que repercuta de manera
  generalizada </span><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'>o significativa en la prestación del servicio,
  la misma</span><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES;mso-bidi-font-weight:bold'> no podrá afectar el
  servicio por más de 24 horas consecutivas; el PROVEEDOR </span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>dejará de cobrar al<span
  style='mso-spacerun:yes'>  </span>SUSCRIPTORla parte proporcional del precio
  del servicio que se dejó de prestar, y deberá bonificar por lo menos el<span
  style='mso-spacerun:yes'>  </span>20% del monto del periodo que se afectó.</span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES;mso-bidi-font-weight:bold'><o:p></o:p></span></p>
  </td>
  <td width=449 valign=top style='width:269.3pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:7.1pt;margin-bottom:.0001pt;mso-add-space:auto;
  text-align:justify;text-indent:-7.1pt;line-height:normal;mso-list:l2 level1 lfo4;
  mso-hyphenate:none;tab-stops:14.2pt;mso-layout-grid-align:none;punctuation-wrap:
  simple;text-autospace:none;vertical-align:baseline'><![if !supportLists]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'><span style='mso-list:Ignore'>4.</span></span></b><![endif]><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>Cuando el PROVEEDOR realice<b style='mso-bidi-font-weight:
  normal'>cargos indebidos</b>, deberá bonificar el 20% sobre el monto del
  cargo realizado indebidamente.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;margin-bottom:
  .0001pt;mso-add-space:auto;text-align:justify;line-height:normal;mso-hyphenate:
  none;mso-layout-grid-align:none;punctuation-wrap:simple;text-autospace:none;
  vertical-align:baseline'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>A partir de que el PROVEEDOR reciba la llamada
  por parte del SUSCRIPTOR para reportarlas fallas y/o interrupciones en el
  SERVICIO, el PROVEEDOR procederá a verificar el tipo de falla y con base en
  ello, se determinará el tiempo necesario para la reparación, el cual no puede
  exceder las 24 horas siguientes a la recepción del reporte. <o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>DÉCIMA SEGUNDA.
  MECANISMOS DE BONIFICACIÓN Y COMPENSACIÓN. </span></b><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>En
  caso de que proceda la bonificación y/o compensación, el PROVEEDOR se obliga
  a:<b style='mso-bidi-font-weight:normal'><o:p></o:p></b></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:14.2pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;text-indent:-14.2pt;line-height:normal;mso-list:l4 level1 lfo5;
  mso-hyphenate:none;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline'><![if !supportLists]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'><span style='mso-list:Ignore'>1.<span
  style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>Realizarlasa más tardar en la siguiente fecha de
  corte a partir de que se actualice algunos de los supuestos descritos en la
  cláusula anterior.<o:p></o:p></span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:14.2pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraphCxSpLast style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:14.2pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;text-indent:-14.2pt;line-height:normal;mso-list:l4 level1 lfo5;
  mso-hyphenate:none;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline'><![if !supportLists]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'><span style='mso-list:Ignore'>2.<span
  style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>Reflejar en el siguiente estado de cuenta o
  factura, la bonificación y/o compensación realizada, y<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
  0cm;margin-left:14.2pt;margin-bottom:.0001pt;mso-add-space:auto;text-align:
  justify;text-indent:-14.2pt;line-height:normal;mso-list:l4 level1 lfo5;
  mso-hyphenate:none;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline'><![if !supportLists]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'><span style='mso-list:Ignore'>3.<span
  style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>Dicha bonificación y/o compensación se efectuará
  por los medios que pacten las partes.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>DÉCIMA TERCERA:
  TERMINACIÓN Y CANCELACIÓN DEL CONTRATO.</span></b><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>El
  Presente contrato se podrá cancelar por cualquiera de las partes sin
  responsabilidad para ellas en los siguientes casos:<b style='mso-bidi-font-weight:
  normal'><o:p></o:p></b></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></b></p>
  <p class=BodyCxSpFirst style='margin-top:0cm;margin-right:0cm;margin-bottom:
  10.0pt;margin-left:0cm;mso-add-space:auto;text-align:justify;text-indent:
  0cm;mso-list:l5 level1 lfo6;tab-stops:14.2pt;border:none;mso-padding-alt:
  31.0pt 31.0pt 31.0pt 31.0pt'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-hansi-font-family:"Arial Unicode MS";
  border:none'><span style='mso-list:Ignore'>a)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;border:none'><span style='border:none'>Por la imposibilidad
  permanente delPROVEEDOR para continuar con la prestación del SERVICIO, ya sea
  por caso fortuito o fuerza mayor.</span></span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";color:windowtext;border:none'><o:p></o:p></span></p>
  
  <p class=BodyCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;margin-bottom:
  10.0pt;margin-left:0cm;mso-add-space:auto;text-align:justify;text-indent:
  0cm;mso-list:l5 level1 lfo6;tab-stops:14.2pt;border:none;mso-padding-alt:
  31.0pt 31.0pt 31.0pt 31.0pt'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-hansi-font-family:"Arial Unicode MS";
  border:none'><span style='mso-list:Ignore'>b)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;border:none'><span style='border:none'>Si el SUSCRIPTOR no
  subsana en un término de 90 días naturales cualquiera de las causas que
  dieron origen a la suspensión <span style='border:none'>del SERVICIO.</span></span></span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext;border:none'><o:p></o:p></span></p>
  
  <p class=BodyCxSpMiddle style='margin-top:0cm;margin-right:0cm;margin-bottom:
  10.0pt;margin-left:0cm;mso-add-space:auto;text-align:justify;text-indent:
  0cm;mso-list:l5 level1 lfo6;tab-stops:14.2pt;border:none;mso-padding-alt:
  31.0pt 31.0pt 31.0pt 31.0pt'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-hansi-font-family:"Arial Unicode MS";
  border:none'><span style='mso-list:Ignore'>c)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;border:none'><span style='border:none'>Si elSUSCRIPTOR
  conecta aparatos adicionales por su propia cuenta, subarrienda, cede o en
  cualquier forma traspasa los derechos establecidos en el contrato, sin la
  autorización previa y por escrito delPROVEEDOR.</span></span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext;border:none'><o:p></o:p></span></p>
  
  <p class=BodyCxSpMiddle style='margin-top:0cm;margin-right:0cm;margin-bottom:
  10.0pt;margin-left:0cm;mso-add-space:auto;text-align:justify;text-indent:
  0cm;mso-list:l5 level1 lfo6;tab-stops:14.2pt;border:none;mso-padding-alt:
  31.0pt 31.0pt 31.0pt 31.0pt'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-hansi-font-family:"Arial Unicode MS";
  border:none'><span style='mso-list:Ignore'>d)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;border:none'><span style='border:none'>Si el PROVEEDOR no
  presta el SERVICIOen la forma y términos convenidos, contratados, ofrecidos o
  implícitos en la&nbsp;información desplegada en la publicidad del proveedor,
  así como con los índices y parámetros de calidad&nbsp;contratados o
  establecidos por el IFT.<span style='border:none'> </span></span></span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext;border:none'><o:p></o:p></span></p>
  
  <p class=BodyCxSpMiddle style='margin-top:0cm;margin-right:0cm;margin-bottom:
  10.0pt;margin-left:0cm;mso-add-space:auto;text-align:justify;text-indent:
  0cm;mso-list:l5 level1 lfo6;tab-stops:14.2pt;border:none;mso-padding-alt:
  31.0pt 31.0pt 31.0pt 31.0pt'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-hansi-font-family:"Arial Unicode MS";
  border:none'><span style='mso-list:Ignore'>e)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;border:none'><span style='border:none'>Si elSUSCRIPTOR
  proporciona información falsa al PROVEEDOR para la contratación del Servicio.</span></span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext;border:none'><o:p></o:p></span></p>
  
  <p class=BodyCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:0cm;margin-bottom:.0001pt;mso-add-space:auto;text-align:justify;
  text-indent:0cm;mso-list:l5 level1 lfo6;tab-stops:14.2pt 2.0cm;border:none;
  mso-padding-alt:31.0pt 31.0pt 31.0pt 31.0pt'><![if !supportLists]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-hansi-font-family:
  "Arial Unicode MS";border:none'><span style='mso-list:Ignore'>f)<span
  style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext;border:none'><span
  style='border:none'>En caso de modificación unilateral de los términos,
  condiciones y tarifas establecidas en el presente contrato por parte
  delPROVEEDOR.</span></span><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;border:none'><o:p></o:p></span></p>
  <p class=BodyCxSpMiddle style='text-align:justify;tab-stops:14.2pt 2.0cm;
  border:none;mso-padding-alt:31.0pt 31.0pt 31.0pt 31.0pt'><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";color:windowtext;border:none'><o:p>&nbsp;</o:p></span></p>
  <p class=BodyCxSpLast style='margin-top:0cm;margin-right:0cm;margin-bottom:
  10.0pt;margin-left:0cm;mso-add-space:auto;text-align:justify;text-indent:
  0cm;mso-list:l5 level1 lfo6;tab-stops:14.2pt 2.0cm;border:none;mso-padding-alt:
  31.0pt 31.0pt 31.0pt 31.0pt'><![if !supportLists]><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:Arial;mso-hansi-font-family:"Arial Unicode MS";
  border:none'><span style='mso-list:Ignore'>g)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
  </span></span></span></b><![endif]><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;border:none'><span style='border:none'>Por cualquier otra <span
  style='border:none'>causa prevista en la legislación aplicable y vigente</span></span></span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext;border:none'><span
  style='border:none'>.</span></span><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;border:none'><o:p></o:p></span></p>
  <p class=MsoListParagraph style='margin:0cm;margin-bottom:.0001pt;mso-add-space:
  auto;text-align:justify;line-height:normal;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>El SUSCRIPTOR podrá dar por terminado el contrato
  en cualquier momento, dando únicamente el aviso al proveedor a través del
  mismo medio en el cual contrató el servicio, o a través </span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>los medios físicos o electrónicos o digitales o de</span></p>
  </td>
 </tr>
</table>
<br><br><br>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt:
 0cm 5.4pt 0cm 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=281 valign=top style='width:168.45pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpLast style='margin:0cm;margin-bottom:.0001pt;
  mso-add-space:auto;text-align:justify;line-height:normal;mso-layout-grid-align:
  none;punctuation-wrap:simple;text-autospace:none;vertical-align:baseline'><!--[if gte vml 1]><v:shape
   id="_x0000_s1028" type="#_x0000_t75" alt="TVLOG1" style='position:absolute;
   left:0;text-align:left;margin-left:27.95pt;margin-top:10.35pt;width:115.5pt;
   height:31.8pt;z-index:2;visibility:visible;mso-wrap-style:square;
   mso-wrap-distance-left:9pt;mso-wrap-distance-top:0;
   mso-wrap-distance-right:9pt;mso-wrap-distance-bottom:0;
   mso-position-horizontal:absolute;mso-position-horizontal-relative:text;
   mso-position-vertical:absolute;mso-position-vertical-relative:text'>
   <v:imagedata src="contratoOK_archivos/image001.jpg" o:title="TVLOG1"/>
  </v:shape><![endif]--><![if !vml]><span style='mso-ignore:vglayout;
  position:absolute;z-index:2;left:0px;margin-left:37px;margin-top:14px;
  width:154px;height:42px'><img width=154 height=42
  src="image002.jpg" alt=TVLOG1 v:shapes="_x0000_s1028"></span><![endif]><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>
  </td>
  <td width=617 valign=top style='width:370.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>TU VISION TELECABLE<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>MARLA SANTAELLA RODRIGUEZ<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt'>CALLE VENUSTIANO CARRANZA, SN COL CENTRO, SANTA
  MARIA, ZACATEPEC, OAXACA, CP 71050. RFC. SARM800402837<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal'><span lang=EN-US style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt;mso-ansi-language:EN-US'>TEL. 9993306039<span
  style='mso-spacerun:yes'>   </span></span><a href="http://WWW.TUVISION.TV"><span
  lang=EN-US style='font-size:8.0pt;mso-bidi-font-size:11.0pt;mso-ansi-language:
  EN-US'>WWW.TUVISION.TV</span></a><span lang=EN-US style='font-size:8.0pt;
  mso-bidi-font-size:11.0pt;mso-ansi-language:EN-US'><span
  style='mso-spacerun:yes'>  </span>CONTACTO@TUVISION.TV</span><b
  style='mso-bidi-font-weight:normal'><span lang=ES-TRAD style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  letter-spacing:2.0pt;mso-ansi-language:ES-TRAD;mso-fareast-language:ES'><o:p></o:p></span></b></p>
  </td>
 </tr>
</table>
<p class=MsoNormal><o:p>&nbsp;</o:p></p>


<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 align=left
 style='border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-table-lspace:
 7.05pt;margin-left:5.25pt;mso-table-rspace:7.05pt;margin-right:5.25pt;
 mso-table-anchor-vertical:page;mso-table-anchor-horizontal:margin;mso-table-left:
 left;mso-table-top:39.05pt;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;mso-border-insideh:
 none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=446 valign=top style='width:267.65pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline;
  mso-element:frame;mso-element-frame-hspace:7.05pt;mso-element-wrap:around;
  mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
  mso-element-top:39.05pt;mso-height-rule:exactly'><span class=GramE><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>cualquier</span></span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES'> otra
  nueva tecnología que lo permita.</span><span lang=ES-TRAD style='font-size:
  9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'> La cancelación o
  terminación del Contrato no exime al SUCRIPTOR de pagar al PROVEEDOR los
  adeudos generados por el/los Servicio(s) efectivamente recibido(s).<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline;
  mso-element:frame;mso-element-frame-hspace:7.05pt;mso-element-wrap:around;
  mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
  mso-element-top:39.05pt;mso-height-rule:exactly'><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline;
  mso-element:frame;mso-element-frame-hspace:7.05pt;mso-element-wrap:around;
  mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
  mso-element-top:39.05pt;mso-height-rule:exactly'><span lang=ES
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  Calibri;mso-ansi-language:ES;mso-fareast-language:ES'>El CONCESIONARIO
  realizará la devolución de las cantidades que en su caso el SUSCRIPTOR haya
  dado por adelantado y que correspondan a la parte proporcional del servicio
  que con motivo de la cancelación no se haya prestado efectivamente por parte
  del PROVEEDOR.</span><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES-MX'><o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-hyphenate:none;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline;
  mso-element:frame;mso-element-frame-hspace:7.05pt;mso-element-wrap:around;
  mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
  mso-element-top:39.05pt;mso-height-rule:exactly'><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>En caso de terminación del
  presente contrato, el PROVEEDOR debe proporcionar un folio o número de
  registro al SUSCRIPTOR, mismo que puede ser entregado, a elección&nbsp;del
  SUSCRIPTOR, a través de medios físicos o electrónicos o digitales o de
  cualquier otra nueva tecnología que&nbsp;lo permita.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>DÉCIMA CUARTA<span class=GramE>:ACCESIBILIDAD</span>
  PARA PERSONAS CON DISCAPACIDAD</span></b><span lang=ES-TRAD style='font-size:
  9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'>. </span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>En cuanto a la contratación
  para usuarios con discapacidad, el PROVEEDOR estará obligado a poner a
  disposición del SUSCRIPTOR la utilización de otros medios de comunicación
  para dar a conocer las condiciones establecidas en el presente contrato, los
  servicios adicionales y los paquetes que ofrezca<span
  style='mso-spacerun:yes'>  </span>el PROVEEDOR.</span><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><b style='mso-bidi-font-weight:
  normal'><span lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES-MX'>DECIMA QUINTA<span class=GramE>:<span lang=ES-MX
  style='mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;
  background:white;mso-ansi-language:ES-MX;mso-fareast-language:EN-US'>NO</span></span></span></b><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif";background:white'> DISCRIMINACIÓN</span></b><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";background:white'>. El
  PROVEEDOR debe <span class=SpellE>prestarel</span> SERVICIO en
  condiciones&nbsp;equitativas a todo aquel que lo solicite, sin establecer
  privilegios o distinciones en forma discriminatoria,&nbsp;respecto de otros
  SUSCRIPTORES en la misma área de cobertura y en las mismas condiciones de
  contratación.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span lang=ES-TRAD
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES-TRAD;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>En caso de que el PROVEEDOR
  ofrezca condiciones más favorables a uno o más suscriptores situados en
  supuestos equivalentes o similares, el SUSCRIPTOR puede exigir las mismas
  condiciones, siempre y cuando sea posible técnicamente para la prestación del
  Servicio.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>DECIMA <span
  class=SpellE>SEXTA<span class=GramE>:<span style='font-weight:normal'>El</span></span></span></span></b><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'> PROVEEDOR está obligado a
  proteger y tratar conforme a la normatividad aplicable, los datos personales
  que le sean proporcionados</span><span lang=ES style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-ansi-language:ES;mso-fareast-language:ES'> por el<span
  style='mso-spacerun:yes'>  </span>SUSCRIPTOR.<span style='mso-spacerun:yes'> 
  </span><o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-layout-grid-align:none;punctuation-wrap:simple;
  text-autospace:none;vertical-align:baseline;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span lang=ES
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-ansi-language:ES;mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>El PROVEEDOR debe poner a
  disposición del SUSCRIPTOR el aviso de privacidad para que pueda ejercer
  alguno de sus derechos, de conformidad con la Ley Federal de Protección de
  Datos Personales en Posesión de los Particulares.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;tab-stops:14.2pt;mso-layout-grid-align:none;
  punctuation-wrap:simple;text-autospace:none;vertical-align:baseline;
  mso-element:frame;mso-element-frame-hspace:7.05pt;mso-element-wrap:around;
  mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
  mso-element-top:39.05pt;mso-height-rule:exactly'><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif";mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:ES-MX'>El PROVEEDOR para utilizar la información del
  SUSCRIPTOR con fines mercadotécnicos o publicitarios; así como para enviarle
  publicidad sobre bienes, productos o servicios, debe</span><u><o:p></o:p></u></p>
  </td>
  <td width=458 valign=top style='width:274.7pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span class=GramE><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>obtener</span></span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'> el consentimiento expreso en
  la carátula del presente contrato.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:5.05pt;text-align:justify;line-height:
  normal;background:white;mso-element:frame;mso-element-frame-hspace:7.05pt;
  mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>DÉCIMA
  SEPTIMA.</span></b><span lang=ES-TRAD style='font-size:9.0pt;font-family:
  "Arial","sans-serif";mso-fareast-font-family:"Times New Roman";mso-ansi-language:
  ES-TRAD;mso-fareast-language:ES'>EL SUSCRIPTOR podrá presentar sus quejas por
  fallas y/o deficiencias en el servicio y/o equipos; así como consultas,
  contrataciones, cancelaciones, sugerencias y reclamaciones a </span><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>EL PROVEEDOR</span><span
  lang=ES-TRAD style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-ansi-language:ES-TRAD;
  mso-fareast-language:ES'>de manera gratuita por los medios señalados en la
  carátula.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>DÉCIMA <span
  class=SpellE>OCTAVA.<span style='font-weight:normal'>La</span></span></span></b><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'> PROFECO es la autoridad<span
  style='mso-spacerun:yes'>  </span>competente en materia administrativa para
  resolver cualquier&nbsp;controversia que se suscite sobre la interpretación o
  cumplimiento del presente contrato de adhesión. <o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>Al IFT&nbsp;le corresponde
  regular y vigilar la calidad de los Servicios de Telecomunicaciones, así como
  el cumplimiento&nbsp;de las disposiciones administrativas que emita y que
  sean referidas la Norma Oficial Mexicana NOM-184-SCFI-2018.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>DÉCIMA
  NOVENA:</span></b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'> Cuando
  se llegare a iniciar algún procedimiento conciliatorio ante la PROFECO, EL
  PROVEEDOR no podrá interrumpir los servicios. Si el servicio de
  telecomunicaciones se suspendió con posterioridad a la presentación de la
  reclamación y previo a la notificación al PROVEEDOR, la PROFECO deberá
  solicitar <span class=SpellE>restablecerel</span> SERVICIO. Si el servicio se
  suspende posterior a la notificación de la reclamación, la PROFECO requerirá
  al PROVEEDOR el restablecimiento del servicio.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'>En todos los casos, el
  SUSCRIPTOR no está exento de sus obligaciones de pago de los bienes y/o
  Servicios contratados y utilizados, salvo cuando se haya determinado su
  improcedencia.<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:ES-MX'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;background:white;mso-element:frame;mso-element-frame-hspace:
  7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:ES-MX'>VIGESIMA<span
  class=GramE>:<span style='mso-fareast-font-family:Calibri;mso-fareast-theme-font:
  minor-latin;mso-fareast-language:EN-US'>DATOS</span></span></span></b><b
  style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;font-family:
  "Arial","sans-serif"'> REGISTRALES. </span></b><span style='font-size:9.0pt;
  font-family:"Arial","sans-serif"'>Este modelo de Contrato de Adhesión, se
  encuentra registrado en la Procuraduría Federal del Consumidor, con el<span
  style='mso-spacerun:yes'>  </span>número 213 de fecha 23 del mes de Agosto de
  2019.<o:p></o:p></span></p>
  <p class=MsoNormal style='text-align:justify;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:
  page;mso-element-anchor-horizontal:margin;mso-element-top:39.05pt;mso-height-rule:
  exactly'><o:p>&nbsp;</o:p></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-element:frame;mso-element-frame-hspace:7.05pt;
  mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Asimismo, el
  SUSCRIPTOR podrá consultar dicho registro en<o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-element:frame;mso-element-frame-hspace:7.05pt;
  mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><a
  href="https://burocomercial.profeco.gob.mx/ca_spt/Marla__SantaellaRo"><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif";color:windowtext'>https://burocomercial.profeco.gob.mx/ca_spt/Marla__SantaellaRo</span></a><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-element:frame;mso-element-frame-hspace:7.05pt;
  mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><span class=SpellE><span
  class=GramE><u><span style='font-size:9.0pt;font-family:"Arial","sans-serif"'>driguez</span></u></span></span><u><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'>!!Tú_Visión_Telecable_213-2019.pdf</span></u><span
  style='font-size:9.0pt;font-family:"Arial","sans-serif"'> </span>Y en el siguiente
  código:<o:p></o:p></p>
  <center><img src="qr.jpg" width="30%"></center>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-align:
  justify;line-height:normal;mso-element:frame;mso-element-frame-hspace:7.05pt;
  mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
  margin;mso-element-top:39.05pt;mso-height-rule:exactly'><o:p>&nbsp;</o:p></p>
  <p class=MsoNormal style='text-align:justify;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:7.05pt;mso-element-wrap:around;mso-element-anchor-vertical:
  page;mso-element-anchor-horizontal:margin;mso-element-top:39.05pt;mso-height-rule:
  exactly'><span style='font-size:9.0pt;font-family:"Arial","sans-serif"'>Cualquier
  diferencia entre el texto del contrato de adhesión registrado ante la
  Procuraduría Federal del Consumidor y el utilizado en perjuicio del
  SUSCRIPTOR, se tendrá por no puesta.<o:p></o:p></span></p>
  

   <?php
 require_once('../config.php');
  require_once('../conexion.php');
  require_once('../funciones.php');
 $id_cliente=addslashes($_POST['id_cliente']);
 //$id_cliente="AMG00074";

  $query="select concat(nombre,' ',apellido_paterno,' ',apellido_materno) from clientes where id_cliente='".addslashes($_POST['id_cliente'])."'";
  $cliente = @devolverValorQuery($query);
  $nombre_cliente="";
  
  if($cliente[0]!="")
  {
    $nombre_cliente=$cliente[0];
  }

  ?>
   <center><?php echo "<img src=../../../api/public/storage/upload/".$id_cliente.".jpg width=20%>"; ?></center>
    <center><?php echo $nombre_cliente;?></center>
  </td>
 </tr>
 <tr>
 
 </tr>
</table>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</body>

</html>
