<?php
	define('DB_SERVIDOR', 'localhost'); //Nombre del host de la base de datos, en la mayor�a de los casos se usar� este valor.
	define('DB_NOMBRE','tuvisio2_sistema'); // Nombre de la base de datos.
	define('DB_USUARIO','tuvisio2_sistema'); // Nombre del usuario de la base de datos en la mayoria de los casos no se cambiar� este valor.
	define('DB_PASSWORD','Ha210009&#'); // contrase�a de la base de datos.	
	define('RUTA', dirname(__FILE__),'/');
	define('ENCABEZADO','TUVISION - Sistema de Administracion');
	define('PIE_PAGINA','Sistema de Administracion Powered By <b>Akira Redwolf & Mario Villatoro</b>');
?>
