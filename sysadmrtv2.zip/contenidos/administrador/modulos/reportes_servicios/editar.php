    <script>
var cal1,
cal2,
mCal,
mDCal,
newStyleSheet;
var dateFrom = null;
var dateTo = null;
function calendario(obj) {
	
    cal1 = new dhtmlxCalendarObject(obj);
	cal1.setSkin('dhx_skyblue');
	
}
</script>
<script language="javascript" type="text/javascript">
	function _Ajax(id,valor,valor2)
	{
		
		bandera_numeros = false;
		var div_numero = document.getElementById(id);
		if(valor!="null")
		{			
			div_numero.innerHTML = "<img src='imagenes/loading.gif' /> <span style='font-size:10px;'>Cargando ...</span>";
			var cdata = "id="+id+"&valor1="+valor+"&valor2="+valor2;
			$.ajax({
					type: "POST",
					url: "ajaxProcess/reporte_servicio.php",
					data: cdata,
					success: function(datos)
					{
						div_numero.innerHTML = datos;	
						bandera_calles = true;
						bandera_numeros = true;
					}
			});
		}
		else
		{
			div_numero.innerHTML = "No Asignado";
		}
	}
	
	function _Ajax2(id,numero,valor)
	{
		bandera_numeros = false;
		var div_numero = document.getElementById(id+numero);
		if(valor!="null")
		{			
			div_numero.innerHTML = "<img src='imagenes/loading.gif' /> <span style='font-size:10px;'>Cargando ...</span>";
			var cdata = "id="+id+"&valor1="+valor;
			$.ajax({
					type: "POST",
					url: "ajaxProcess/reporte_servicio.php",
					data: cdata,
					success: function(datos)
					{
						div_numero.innerHTML = datos;	
						bandera_calles = true;
						bandera_numeros = true;
					}
			});
		}
		else
		{
			div_numero.innerHTML = "No Asignado";
		}
	}
	
	function agregar(){

		if(document.getElementById('services')){

			var tabla_mayor=document.getElementById('services');
			var tbody=document.createElement('tbody');
			var fila=document.createElement('tr');
			fila.id = 'dinamico_' + (++count);
			
			
			var campo1=document.createElement('div');
			var campo2=document.createElement('img');
			
			campo2.src='imagenes/del.png';
			campo2.name = fila.id;
			campo2.onclick = elimCamp;
			
			campo1.id="serv_aux"+count;
			
			var celda=document.createElement('td');
			var celda2=document.createElement('td');
			
			celda.appendChild(campo1);
			celda2.appendChild(campo2);
			
			
			fila.appendChild(celda);
			fila.appendChild(celda2);
	   
		   tbody.appendChild(fila);	
		   tabla_mayor.appendChild(tbody);
		   _Ajax2('serv_aux',count,document.getElementById('t_serv')[document.getElementById('t_serv').selectedIndex].value);
		}
	   
	}
	
	evento = function (evt)
	{ //esta funcion nos devuelve el tipo de evento disparado
	   return (!evt) ? event : evt;
	}

	elimCamp = function(evt)
	{
		evt = evento(evt);
	   nCampo = rObj(evt);
	  

	   div_eliminar = document.getElementById(nCampo.name);
	   div_eliminar.parentNode.removeChild(div_eliminar);
	}
	
	rObj = function (evt)
	{ 
		return evt.srcElement ?  evt.srcElement : evt.target;
	}
	
	function crea_nota(){
		if(document.getElementById('id_cliente')){
			if(document.getElementById('t_serv')[document.getElementById('t_serv').selectedIndex].value==1){
				_Ajax('nota',document.getElementById('id_cliente').value);	
			}else{
				_Ajax('nota');	
			}	
		}else{
			document.getElementById('nota').innerHTML = "<span>Seleccione 'nota' en tipo de servicio y un cliente</span>";	
		}		
	}
	
	var contenedor_empleado = ""; //Se actualiza para saber en que input se coloca la llave del cliente
	var contenedor_cliente = ""; //Se actualiza para saber en que input se coloca la llave del cliente
	var parametro_sucursal_empleado = "";// Se utiliza en caso de que queramos la lista de clientes de una sucursal en especifica
	var parametro_sucursal_cliente = "";// Se utiliza en caso de que queramos la lista de clientes de una sucursal en especifica
	function cambio_id_empleado(id){
		
		}
	
	function cambio_id_cliente(id){	
		crea_nota();
		if(document.getElementById('t_serv')[document.getElementById('t_serv').selectedIndex].value){
			_Ajax('servicio',document.getElementById('t_serv')[document.getElementById('t_serv').selectedIndex].value);	
		}
		_Ajax('taps',id);
	}
	
	function fechas(caja)
	{ 
		
	   if (caja.value)
	   {  
		  borrar = caja.value;
		  if ((caja.value.substr(4,1) == "-") && (caja.value.substr(7,1) == "-"))
		  {    			
			 if (borrar)
			 { 
				a = caja.value.substr(0,4);
				m = caja.value.substr(5,2);
				d = caja.value.substr(8,2);
				if((a < 1900) || (a > 2050) || (m < 1) || (m > 12) || (d < 1) || (d > 31))
				   borrar = '';
				else
				{
				   if((a%4 != 0) && (m == 2) && (d > 28))	   
					  borrar = ''; // A�o no viciesto y es febrero y el dia es mayor a 28
				   else	
				   {
					  if ((((m == 4) || (m == 6) || (m == 9) || (m==11)) && (d>30)) || ((m==2) && (d>29)))
						 borrar = '';	      				  	 
				   }
				}
			 }
		  }		    			
		  else
			 borrar = '';
		  if (borrar == '')
		  {
			 alert('Fecha erronea');
			 caja.value = borrar;
		   }
	   }  
	}
	
	function cambios(val1){

		valores = val1.split(" ");
		document.formulario.tap.value=valores[0];
		document.formulario.valor.value=valores[1];
		document.formulario.salida.value=valores[2];
	}
</script>
<?php
  
  		
		if(isset($_GET['id']))
			$id=$_GET['id'];
		
		if(isset($_POST['select'])){
			$aux=array_keys($_POST['select']);
		    $id=$aux[0];
		}
		
			
		else
		{
		
			
			foreach($_POST as $variable => $valor)
			{
				if($variable != "selector")
				{
					if($variable != "accion")
					{
						$id = $variable;
					}
				}
			}
		}
		if(isset($id))
		{
			
			$lista=array();
			$query_serv = "select 
			id_tipo_servicio
			from cliente_servicios  where id_reporte='".addslashes($id)."'";
			$res=mysqli_query($conexion,$query_serv);
			while(list($valor)=mysqli_fetch_array($res)){
				array_push($lista,$valor);	
			}
			
			
			
			
			$query = "select 
			substr(id_cliente,1,3),
			id_empleado,
			id_cliente,
			folio,
			fecha_reporte,
			id_tipo_atencion,
			fecha_atencion,
			descripcion_atencion,
			importe_inputable,
			nota_inputable,
			id_peticion,
			id_ingreso,
			id_estatus_servicio
			from reporte_servicios rs where id_reporte='".addslashes($id)."'";
			$registro = devolverValorQuery($query);
			if($registro[0]!='')
			{
				if($registro[12]==1){
				

	?>    





    
<form name="formulario" method="post" onsubmit="return false;" action="index.php?menu=18">



<input type="hidden" name="id" value="<?php echo addslashes($_GET['id']) ?>" />
<table border="0px"  width="100%" style="color:#000000;font-size:12px">
	<tr>    
    	<td align="right">
        	<table border="0" width="100%" cellpadding="0" cellspacing="0" >
            	<tr>
            	<td width="5px" background="imagenes/module_left.png"></td>
                <td width="70px" background="imagenes/module_center.png" height="80"  valign="middle"><img src="imagenes/reportes_servicios.png" /></td>
                <td align="left" background="imagenes/module_center.png" height="80" valign="middle" class="titulo"><b>&nbsp;&nbsp;EDITAR REPORTE</b></td>
                <td align="right" background="imagenes/module_center.png" height="80" >
                    <!--<button class="boton2" id="guardar" onclick="save();" ><img src="imagenes/guardar.png" /><br/>Guardar</button>-->
                    <button class="boton2" id="guardar" onclick="atender();" ><img src="imagenes/Ok.png" /><br/>Atendido</button>
					<button class="boton2" onclick="location.href='index.php?menu=18'"><img src="imagenes/cancelar.png" /><br />Cancelar</button>
                </td>
                <td width="5px" background="imagenes/module_right.png"></td>
                </tr>
            </table>
        </td>
	</tr>	
    
    
    
    <tr><td height="10px"></td></tr>
	<tr>
		<td colspan="3">
			<table class="datagrid" width="100%" border="0" cellspacing="0">
				<tr><td  height="3px" class="separador"></td></tr>
				<tr class="tabla_columns">
					<td >Detalles</td>
				</tr>
				<tr>
					<td>
				  		<table style="color:#000000" cellpadding="5">
                            <tr>
                        	  <td>Folio:</td><td><input style="width:200px;font-size:12px;" type="text" value="<?php echo $registro[3]; ?>" readonly="readonly"/>
          </td>
          <td>Fecha de Reporte:</td><td><input name="fecha" style="width:200px;font-size:12px;" type="text" maxlength="255" value="<?php echo $registro[4]; ?>" readonly="readonly"/></td>
          </tr>
                              <tr>
                        	  <td>Sucursal:</td><td>
                              <select name="sucursal" onchange="_Ajax('clientes',this.value);crea_nota(document.getElementById('t_serv').value,this.value);_Ajax('servicio');" style="width:300px; font-size:12px;">
                                    	<option value="null">Elige una Sucursal</option>
										<?php
											$query_t_u = "select * from sucursales order by id_sucursal asc";
											$tabla_t_u = mysqli_query($conexion,$query_t_u);
											while($registro_t_u = mysqli_fetch_array($tabla_t_u))
											{
												if($registro_t_u[0]==$registro[0])
												echo "<option value=\"$registro_t_u[0]\" selected>$registro_t_u[0] - $registro_t_u[1]</option>";
												else
												echo "<option value=\"$registro_t_u[0]\">$registro_t_u[0] - $registro_t_u[1]</option>";
											}
                                        ?>
                                    </select>
                              </td></tr>
                              
                              <tr>
                        	  <td>Responsable:</td><td>
                              <input name="empleado" id="autorizox" readonly="readonly" style="width:110px;font-size:12px;" type="text" maxlength="12" value="<?php echo $_SESSION['tuvision_id_empleado']; ?>" />
                              </td></tr>
                               
                               <tr>
                        	  <td>Cliente:</td><td>
                              <div id="clientes">
                              	<input name="id_cliente" id="id_cliente" readonly="readonly" style="width:110px;font-size:12px;" type="text" maxlength="12"  value="<?php echo $registro[2]; ?>"/>&nbsp;<img style="cursor:pointer;position:relative; top:4px;" onclick="contenedor_cliente='id_cliente';parametro_sucursal_cliente=document.formulario.sucursal[document.formulario.sucursal.selectedIndex].value;createWindow('Buscar Cliente',450,310 ,1,false,true);" src="imagenes/popup.png" />
                              </div>
                              </td></tr>
                               
                              <tr>
                        	  <td>Fecha de Atencion:</td><td>
                              <input name="fecha_atencion" id="fecha_atecion"  style="width:90px;font-size:12px; background-image:url(calendario/imgs/icon_minicalendar.gif); background-position:right center; background-repeat:no-repeat;" type="text" maxlength="10" readonly="readonly" onfocus="calendario(this.id);" value="<?php echo $registro[6]; ?>"/>
                              </td></tr>
                              
                              <tr>
                        	  <td>Descripci&oacute;n de Atencion:</td><td><textarea name="descripcion_atencion" cols="50"><?php echo $registro[7]; ?></textarea></td></tr>			
                              		
                              <tr>
                        	  <td>Importe Imputable:</td><td><input name="importe_imputable" style="width:200px;font-size:12px;" type="text" maxlength="255" value="<?php echo $registro[8]; ?>" onkeyup="solo_numeros_decimales(this);" onblur="solo_numeros_decimales(this)"/></td></tr>
                              
                              <tr>
                                <td height="51">Numero de Nota (Imputable):</td><td><input type="text" name="nota_imputable" cols="50" value="<?php echo $registro[9]; ?>" style="width:70px;font-size:12px;" onblur="solo_numeros(this)" onkeyup="solo_numeros(this)"></td></tr>
                                
                              <tr>
                              	<td colspan="4">
                                <div id="taps">
                                <?php
								$query = "select 
									(select id_tap from tap where id_tap=c.id_tap),
									(select valor from tap where id_tap=c.id_tap),
									(select salidas from tap where id_tap=c.id_tap)
									from clientes c where id_cliente='".$registro[2]."'";
									$result = mysqli_query($conexion,$query);
									list($id,$valor,$salidas)=mysqli_fetch_array($result);
									
									$select = "select id_tap, valor, salidas from tap where id_sucursal = (select id_sucursal from clientes where id_cliente='".$registro[2]."')";
									$ext=mysqli_query($conexion,$select);
									
									?>
									
									<table border="0" cellpadding="0" cellspacing="0">
										<tr>
										  <td>Id Tap:</td><td>
										  <?php
										  echo "<select name='id_tap' onchange=\"cambios(this.value)\">";
											while(list($taps , $val, $sal)=mysqli_fetch_array($ext)){
												if($taps==$id)
												echo "<option value='$taps $val $sal' selected >$taps</option>";
												else
												echo "<option value='$taps $val $sal'>$taps</option>";
												
											}
											echo "</select>";
										  ?>
										  
										  <td width="30"></td>


										  <td>Valor:</td><td><input type="text" name="valor"  value="<?php echo $valor; ?>" readonly="readonly"/></td>
										  <td width="30"></td>
										  <td>Salida:</td><td><input type="text" name="salida"  value="<?php echo $salidas; ?>" readonly="readonly"/></td>

										</tr>
									</table>
								
                                </div>
                                </td>
                              </tr>
                              <input type="hidden" name="tap" />  
                              <tr>
                        	  <td>Tipo de Atencion:</td><td>
                               <div id="t_atencion">
                              	<select name="t_atencion" style="width:300px; font-size:12px;">
                                    <option value="null">Seleccione un tipo de atencion</option>
                                    <?php
                                    $query = "select id_tipo_atencion,descripcion from cat_tipo_atencion";
                                    $result = mysqli_query($conexion,$query);
                                    while(list($id,$nombre)=mysqli_fetch_array($result)){
                                        if($id==$registro[5])
                                            echo "<option value='$id' selected>$nombre</option>";
                                            else
                                            echo "<option value='$id'>$nombre</option>";
                                    }
									?>
                                </select>
                              </div>
                              </td></tr>
                              
                              <tr>
                              	<td>Tipo de servicio:</td>
                                	<td>
                                        <select name="tipo_servicio" id="t_serv" style="width:300px; font-size:12px;" onchange="_Ajax('servicio',this.value);crea_nota();">
                                           
                                            <?php
                                                $query_t_u = "select * from cat_peticion_servicio order by id_peticion asc";
                                                $tabla_t_u = mysqli_query($conexion,$query_t_u);
                                                while($registro_t_u = mysqli_fetch_array($tabla_t_u))
                                                {
													if($registro[10]==$registro_t_u[0])
                                                    echo "<option value=\"$registro_t_u[0]\" selected>$registro_t_u[1]</option>";
													
                                                }
                                            ?>
                                        </select>
                                 	</td>
                              </tr>
                                                            
                              <tr>
                        	  <td>N&uacute;mero de nota:</td><td>
                              <div id="nota">
                              <?php

							  if($registro[10]==1){
							 $query = "select id_ingreso,folio_nota from ingresos where id_cliente='".$registro[2]."'";
			
								echo "<select name='folio' style='width:300px; font-size:12px;' onchange=\"_Ajax('servicio','nota',this.value);\">";
								
								
								
								$result = mysqli_query($conexion,$query);
								while(list($id,$nombre)=mysqli_fetch_array($result)){
									if($id==$registro[11])
										echo "<option value='$id' selected>$nombre</option>";
										
								}
								echo "</select>";
							}else{
								echo "Seleccione \"nota\" en tipo de servicio y un cliente";	
							}
							  ?>
                              </div>
                              
                              </td></tr>
                              
                                
						</table>
						<input name="accion"  type="hidden" value="editar" />
					</td>
                </tr>
                <tr><td  height="3px" class="separador"></td></tr>
          </table>
	</td>
	</tr>
	
</table>

<table width="100%">
	<tr>
		<td>
            <table class="datagrid" width="100%" border="0" cellspacing="0">
                <tr>
                    <td  height="3px" class="separador"></td></tr>
                <tr class="tabla_columns">
                    <td >SERVICIOS</td>
                </tr>
                <tr>
                    <td>
                        <table border='0' cellspacing='0' cellsppadding='0'>
                        	<tr>
                            	<td>
                                    <div id="servicio">
                                    <?php
										if($registro[10]==1){
											$query = "select id_tipo_servicio,descripcion from cat_tipo_servicios where id_tipo_servicio in (select id_tipo_servicio from rel_tipo_ingreso_servicio where id_tipo_ingreso in (select id_tipo_ingreso from montos where id_ingreso='$registro[11]'))";
										echo "<table border='0' cellspacing='0' cellsppadding=0><tr><td>";
									
											echo "<table id='services' width='100%' border='0' cellspacing='0'>";
											
											$result = mysqli_query($conexion,$query);
											if(mysqli_num_rows($result))
											while(list($id,$nombre)=mysqli_fetch_array($result)){
												echo "<tr><td>";
												echo "<select name='servicio[]' id='serviciox' style='width:300px; font-size:12px;'>";
													echo "<option value='$id'>$nombre</option>";
												echo "</select>";
												echo "</td>";
												echo "<td><img src=''</td>";
												echo "</tr>";
											}
										else{
											echo "<tr><td>No asignado</td></tr>";	
										}
										
										echo "</table></td></tr>";
										
										echo "</table>";
											
											}else{
												
											$conta=0;
											
											$query = "select id_tipo_servicio,descripcion from cat_tipo_servicios where id_peticion='$registro[10]'";
											echo "<table border='0' cellspacing='0' cellsppadding=0><tr><td>";
										
												echo "<table id='services' width='100%' border='0' cellspacing='0'>";
												
												foreach($lista as $valores){
													$conta++;
													echo "<tr id='dinamicon_$conta'><td>";
													
													echo "<select name='servicio[]' style='width:300px; font-size:12px;'>";

													
													$result = mysqli_query($conexion,$query);
													while(list($id,$nombre)=mysqli_fetch_array($result)){
														if($id==$valores)
															echo "<option value='$id' selected>$nombre</option>";
															
													}
													echo "</select>";
													
													
													echo "</tr>";
											}
											echo "</table></td></tr>";
											
											echo "</table>";	
											}
									?>
                                    <table id='services' width='100%' border='0' cellspacing='0'>
                                    </table>
                                    
                                    </div>
                                
		                        </td>
        		             </tr>
                		     
                		</table>    
        			</td>    
				</tr>
                <tr><td  height="3px" class="separador"></td></tr>
			</table>    
		</td>
	</tr>
</table>

<table border="0px"  width="100%" style="color:#000000;font-size:12px">
<tr>
    <td>
        <table border="0px"  width="100%" cellspacing="0" cellpadding="0" style="color:#000000;font-size:12px">
        <tr><td height="10px"></td></tr>
            <tr>
                <td colspan="3">
                    <table class="datagrid" id="materiales" width="100%" border="0" cellspacing="0">
                        <tr><td colspan="6"  height="3px" class="separador"></td></tr>
                        <tr class="tabla_columns">
                            <td colspan="2">Lista de Materiales en Buen Estado</td>
                            <td colspan="3">Lista de Materiales de Reemplazo</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Nombre</td>
                            <td>Cantidad</td>
                            <td>Nombre</td>
                            <td>Cantidad</td>
                            <td>Comentario</td>
                            <td></td>
                        </tr>
                        <?php
						
                                if(isset($_GET['id']))
									$id=$_GET['id'];
								
								if(isset($_POST['select'])){
									$aux=array_keys($_POST['select']);
									$id=$aux[0];
								}
                        $material = "select id_material,nom_bueno,cantidad_bueno,nom_reemplazo,cantidad_reemplazo,comentario from material where id_reporte='".addslashes($id)."'";
                        $resultado = mysqli_query($conexion,$material);
                        $row = mysqli_num_rows($resultado);
                        
                        $contador=0;
                        while(list($id,$bueno,$can_bueno,$reemplazo,$can_reemplazo,$comentario)=mysqli_fetch_array($resultado)){
                            echo "<tr id='".(++$contador)."'>";
                            echo "<td><select name='nombre[]'>";
							echo "<option value='null'>Seleccione un material</option>";
								$query = "select id_equipo_inventario, descripcion from cat_equipos_inventario";
								$res = mysqli_query($conexion,$query);
								while(list($id,$des) = mysqli_fetch_array($res)){
									if($id==$bueno)
									echo "<option value='$id' selected>$des</option>";
									else
									echo "<option value='$id'>$des</option>";
								}
								echo "</option>";
								echo "</select>";
							echo "</td>";
                            echo "<td><input type='text' name='cantidad[]' value='".$can_bueno."' style='width:50px;font-size:12px;'   onkeyup='solo_numeros(this);'  onblur='solo_numeros(this);'></td>";
                            
							echo "<td><select name='nombre2[]'>";
							echo "<option value='null'>Seleccione un material</option>";
								$query = "select id_equipo_inventario, descripcion from cat_equipos_inventario";
								$res = mysqli_query($conexion,$query);
								while(list($id,$des) = mysqli_fetch_array($res)){
									if($id==$reemplazo)
									echo "<option value='$id' selected>$des</option>";
									else
									echo "<option value='$id'>$des</option>";
								}
								echo "</option>";
								echo "</select>";
							echo "</td>";
							
							
                            echo "<td><input type='text' name='cantidad2[]' value='".$can_reemplazo."' style='width:50px;font-size:12px;'   onkeyup='solo_numeros(this);'  onblur='solo_numeros(this); size='5'></td>";
                            echo "<td><input type='text' name='comentario[]' value='".$comentario."' style='width:50px;font-size:12px;'></td>";
                            
                            echo "<td><img src='imagenes/del.png' onclick=\"elimCamp2('$contador')\">";
                            
                            echo "<input type='hidden' name='ids[$id]' />
                            </td></tr>";
                        }
                        ?>
                           
                    </table>
                     
                </td>
            </tr>  
             <tr><td colspan="6" height="3px" class="separador"></td></tr> 
             <tr><td><input type="button" value="Agregar nuevo material" onclick="crea_fila()" /></td></tr>   
            
                       
        </table>
        </td>
    </tr>
</table>

<input type="hidden" name="estado" id="estado" />

<script language="javascript">
var count=10000;
var bandera_numeros=true;


function validar_arreglos(id,tipo){

	var campo = document.getElementsByName(id);
	var counter = 0;
	if(campo){
		for (var i = 0; i < campo.length; i++) {
			if(tipo==1){
				if (campo[i][campo[i].selectedIndex].value=='null') {
					counter++;
				}
			}else if(tipo==2){
				if (campo[i].value=='') {
					counter++;
				}
			}
		}

		
		if(counter==0)
			return false;
		else if(counter!=0)
			return true;
			
	}else{
		return false;
	}
}

function atender(){
	var cadena="";
	if(document.formulario.sucursal.value=='null'){
			cadena +="\n Debe de elegir una sucursal";
		}
		
		
		if(document.formulario.id_cliente)
		if(document.formulario.id_cliente.value==''){
			cadena +="\n Debe de elegir un cliente";
		}
		
		if(document.formulario.empleado)
		if(document.formulario.empleado.value==''){
			cadena +="\n Debe de elegir un empleado";
		}
		
		if(document.formulario.ingreso)
		if(document.formulario.ingreso.value=='null'){
			cadena +="\n Debe de elegir un folio";
		}
		
		if(document.formulario.fecha_atencion.value==''){
			cadena +="\n Debe de ingresar una fecha de atencion";
		}
		
		if(document.formulario.descripcion_atencion.value==''){
			cadena +="\n Debe de ingresar la descripcion de la atencion";
		}
		
		/*if(document.formulario.importe_imputable.value==''){
			cadena +="\n Debe de ingresar el importe imputable";
		}
		
		if(document.formulario.nota_imputable.value==''){
			cadena +="\n Debe de ingresar la nota imputable";
		}*/
	
		if(document.formulario.t_atencion)
		if(document.formulario.t_atencion.value=='null'){
			cadena +="\n Debe de elegir el tipo de atencion";
		}
		
		if(validar_arreglos("servicio[]",1)){
			cadena +="\n Debe de ingresar todos los servicios";
		}
		
		if(validar_arreglos("nombre[]",1)){
			cadena +="\n Debe de ingresar todos los nombres de los materiales en buen estado";
		}
		
		if(validar_arreglos("cantidad[]",2)){
			cadena +="\n Debe de ingresar todas las cantidades de los materiales en buen estado";
		}
		
		if(validar_arreglos("nombre2[]",1)){
			cadena +="\n Debe de ingresar todos los nombres de los materiales de reemplazo";
		}
		if(validar_arreglos("cantidad2[]",2)){
			cadena +="\n Debe de ingresar todas las cantidades de los materiales de reemplazo";
		}
		if(validar_arreglos("comentario[]",2)){
			cadena +="\n Debe de ingresar todos los comentarios";
		}

		if(document.getElementById('t_serv')[document.getElementById('t_serv').selectedIndex].value==1){

			if(document.formulario.folio.value!='null'){

				if(!document.getElementById('serviciox')){
					cadena +="\n Este folio no contiene servicio favor de elegir otra nota";	
				}	
			}
		}
		
		if(bandera_numeros==false && cadena==""){
			cadena +="\n Faltan campos por cargar por favor espere un momento";
		}
		
		
				
		if(cadena == "" )
		{
			document.getElementById('estado').value="2";	
			document.formulario.submit();
		}
		else
			alert("Por favor verifique lo siguiente:"+cadena);
	
}
	
function save()
	{
		
		var cadena="";
		document.getElementById('estado').value='1';
		
		if(document.formulario.sucursal.value=='null'){
			cadena +="\n Debe de elegir una sucursal";
		}
		
		
		if(document.formulario.id_cliente)
		if(document.formulario.id_cliente.value==''){
			cadena +="\n Debe de elegir un cliente";
		}
		
		if(document.formulario.empleado)
		if(document.formulario.empleado.value==''){
			cadena +="\n Debe de elegir un empleado";
		}
		
		if(document.formulario.ingreso)
		if(document.formulario.ingreso.value=='null'){
			cadena +="\n Debe de elegir un folio";
		}
		
		if(document.formulario.fecha_atencion.value==''){
			cadena +="\n Debe de ingresar una fecha de atencion";
		}
		
		if(document.formulario.descripcion_atencion.value==''){
			cadena +="\n Debe de ingresar la descripcion de la atencion";
		}
		
		/*if(document.formulario.importe_imputable.value==''){
			cadena +="\n Debe de ingresar el importe imputable";
		}
		
		if(document.formulario.nota_imputable.value==''){
			cadena +="\n Debe de ingresar la nota imputable";
		}*/
	
		if(document.formulario.t_atencion)
		if(document.formulario.t_atencion.value=='null'){
			cadena +="\n Debe de elegir el tipo de atencion";
		}
		
		if(validar_arreglos("servicio[]",1)){
			cadena +="\n Debe de ingresar todos los servicios";
		}
		
		if(validar_arreglos("nombre[]",1)){
			cadena +="\n Debe de ingresar todos los nombres de los materiales en buen estado";
		}
		
		if(validar_arreglos("cantidad[]",2)){
			cadena +="\n Debe de ingresar todas las cantidades de los materiales en buen estado";
		}
		
		if(validar_arreglos("nombre2[]",1)){
			cadena +="\n Debe de ingresar todos los nombres de los materiales de reemplazo";
		}
		if(validar_arreglos("cantidad2[]",2)){
			cadena +="\n Debe de ingresar todas las cantidades de los materiales de reemplazo";
		}
		if(validar_arreglos("comentario[]",2)){
			cadena +="\n Debe de ingresar todos los comentarios";
		}
		
		
		if(document.getElementById('t_serv')[document.getElementById('t_serv').selectedIndex].value==1){
			if(document.formulario.folio.value!='null'){
				if(!document.getElementById('serviciox')){
					cadena +="\n Este folio no contiene servicio favor de elegir otra nota";	
				}	
			}
		}
		
		if(bandera_numeros==false && cadena==""){
			cadena +="\n Faltan campos por cargar por favor espere un momento";
		}
		
		
				
		if(cadena == "" )
		{
			
			document.formulario.submit();
		}
		else
			alert("Por favor verifique lo siguiente:"+cadena);
	}

function elimCamp2(nCampo)
	{
	
	  div_eliminar = document.getElementById(nCampo);
	   
	   div_eliminar.parentNode.removeChild(div_eliminar);
	}
evento = function (evt)
	{ //esta funcion nos devuelve el tipo de evento disparado
	   return (!evt) ? event : evt;
	}
	
	elimCamp = function(evt)
	{
		evt = evento(evt);
	   nCampo = rObj(evt);
	  
	
	   div_eliminar = document.getElementById(nCampo.name);
	   div_eliminar.parentNode.removeChild(div_eliminar);
	}
	rObj = function (evt)
	{ 
		return evt.srcElement ?  evt.srcElement : evt.target;
	}
	
	function crea_fila(){
		
		var tbody=document.createElement('tbody');
   		var fila=document.createElement('tr');
		fila.id = 'dinamic_' + (++count);
		
   		var celda1=document.createElement('td');
		var celda2=document.createElement('td');
		var celda3=document.createElement('td');
		var celda4=document.createElement('td');
		var celda5=document.createElement('td');
		var celda6=document.createElement('td');
		
		var campox=document.createElement('div');
		var campox2=document.createElement('div');
   		var campo1=document.createElement('select');
		var campo2=document.createElement('input');
		var campo3=document.createElement('select');
		var campo4=document.createElement('input');
		var campo5=document.createElement('input');
		var campo6=document.createElement('img');
		
		campox.id='material'+count;
		campox2.id='material2'+count;
		campo1.name="nombre[]";
		campo2.name="cantidad[]";
		campo2.id="cantidad_"+count;
		campo3.name="nombre2[]";
		campo4.name="cantidad2[]";
		campo4.id="cantidad2_"+count;
		campo5.name="comentario[]";
		
		campo2.onblur=function(){
			solo_numeros2(this.id);
		}
		
		campo2.onkeyup=function(){
			solo_numeros2(this.id);
		}
		
		campo4.onblur=function(){
			solo_numeros2(this.id);
		}
		
		campo4.onkeyup=function(){
			solo_numeros2(this.id);
		}
		
		campo6.src='imagenes/del.png';
		
		campo6.name = fila.id;
		campo6.onclick = elimCamp;
		
		
		campo2.style.fontSize="12px";
		campo2.style.width="50px";
		campo4.style.fontSize="12px";
		campo4.style.width="50px";
		campo5.style.fontSize="12px";
		campo5.style.width="200px";
		
		campox.appendChild(campo1);
		campox2.appendChild(campo3);
		celda1.appendChild(campox);
		celda2.appendChild(campo2);
		celda3.appendChild(campox2);
		celda4.appendChild(campo4);
		celda5.appendChild(campo5);
		celda6.appendChild(campo6);
		
		fila.appendChild(celda1);
		fila.appendChild(celda2);
		fila.appendChild(celda3);
		fila.appendChild(celda4);
		fila.appendChild(celda5);
		fila.appendChild(celda6);
		
   		tbody.appendChild(fila);	
		
	   document.getElementById('materiales').appendChild(fila);
	   _Ajax2('material',count);
	    _Ajax2('material2',count);
		
	}
	
	function solo_numeros(texto)
	{
		var expresion = /[0-9]*/;
		texto.value = texto.value.match(expresion);
	}
	function solo_numeros_decimales(texto)
	{
		var expresion = /[0-9]*\.?[0-9]{0,2}/;
		texto.value = texto.value.match(expresion);
	}
	
	function solo_numeros2(texto)
	{
		var expresion = /[0-9]*/;
		document.getElementById(texto).value = document.getElementById(texto).value.match(expresion);
	}
	function solo_numeros_decimales2(texto)
	{
		var expresion = /[0-9]*\.?[0-9]{0,2}/;
		document.getElementById(texto).value = document.getElementById(texto).value.match(expresion);
	}
	
	</script>
    


</form>


<?php
		}else{
			
			$query2 = "select 
			id_empleado,
			id_cliente,
			folio,
			fecha_reporte,
			(select descripcion from cat_tipo_atencion where id_tipo_atencion=rs.id_tipo_atencion),
			fecha_atencion,
			descripcion_atencion,
			importe_inputable,
			nota_inputable,
			id_peticion,
			id_ingreso,
			id_estatus_servicio,
			(select nombre from sucursales where id_sucursal = (select id_sucursal from empleados where id_empleado=rs.id_empleado))
			from reporte_servicios rs where id_reporte='".addslashes($id)."'";
			
			$resx = mysqli_query($conexion,$query2);
			list($emp,$cli,$folio,$f_rep,$atencion,$f_aten,$des_aten,$imp_inp,$nota_imp,$peticion,$ingreso,$servicio,$sucur)=mysqli_fetch_array($resx);
		?>
                
               
        <table border="0px"  width="100%" style="color:#000000;font-size:12px">
            <tr>    
                <td align="right">
                    <table border="0" width="100%" cellpadding="0" cellspacing="0" >
                        <tr>
                        <td width="5px" background="imagenes/module_left.png"></td>
                        <td width="70px" background="imagenes/module_center.png" height="80"  valign="middle"><img src="imagenes/reportes_servicios.png" /></td>
                        <td align="left" background="imagenes/module_center.png" height="80" valign="middle" class="titulo"><b>&nbsp;&nbsp;REPORTE
                        <?php if($registro[12]==2)
								echo "ATENDIDO";
								else
								echo "CANCELADO";
						?>
                         </b></td>
                        <td align="right" background="imagenes/module_center.png" height="80" >
                            <button class="boton2" onclick="location.href='index.php?menu=18'"><img src="imagenes/back.png" /><br />Regresar</button>
                        </td>
                        <td width="5px" background="imagenes/module_right.png"></td>
                        </tr>
                    </table>
                </td>
            </tr>	
            
            
            
            <tr><td height="10px"></td></tr>
            <tr>
                <td colspan="3">
                    <table class="datagrid" width="100%" border="0" cellspacing="0">
                        <tr><td  height="3px" class="separador"></td></tr>
                        <tr class="tabla_columns">
                            <td >Detalles</td>
                        </tr>
                        <tr>
                            <td>
                                <table style="color:#000000" cellpadding="5">
                                    <tr>
                                      <td>Folio:</td><td><?php echo $folio; ?>
                                      </td>
                                      <td>Fecha de Reporte:</td><td><?php echo $f_rep; ?></td>
                                      </tr>
                                      <tr>
                                      <td>Sucursal:</td><td>
                                      <?php echo $sucur; ?>
                                      </td></tr>
                                      
                                      <tr>
                                      <td>Responsable:</td><td>
                                      <?php echo $emp; ?>
                                      </td></tr>
                                       
                                       <tr>
                                      <td>Cliente:</td><td>
                                      <?php echo $cli; ?>
                                      </td></tr>
                                       
                                      <tr>
                                      <td>Fecha de Atencion:</td><td><?php echo $f_aten; ?></td></tr>
                                      
                                      <tr>
                                      <td>Descripci&oacute;n de Atencion:</td><td style="max-width:300px"><?php echo $des_aten; ?></td></tr>			
                                            
                                      <tr>
                                      <td>Importe Imputable:</td><td><?php echo $imp_inp; ?></td></tr>
                                      
                                      <tr><td height="51">Nota Imputable:</td><td><?php echo $nota_imp; ?></td></tr>
                                      <tr>
                                      <td>Tipo de Atencion:</td><td>
                                      <?php echo $atencion; ?>
                                     
                                      </td></tr>
                                      
                                      <tr>
                                        <td>Tipo de servicio:</td>
                                            <td>
												<?php echo $peticion; ?>
                                            </td>
                                      </tr>
                                                                    
                                      <tr>
                                      <td>N&uacute;mero de nota:</td><td>
                                      <div id="nota">
                                      <?php
        
                                      if($ingreso!='null'){
                                      $query = "select folio_nota from ingresos where id_ingreso='".$ingreso."'";
                                                                                                    
                                        $result = mysqli_query($conexion,$query);
                                        list($id)=mysqli_fetch_array($result);
                                           echo $id; 
                                        
                                    }else{
                                        echo "Seleccione \"nota\" en tipo de servicio y un cliente";	
                                    }
                                      ?>
                                      </div>
                                      
                                      </td></tr>
                                      
                                        
                                </table>
                                <input name="accion"  type="hidden" value="editar" />
                            </td>
                        </tr>
                        <tr><td  height="3px" class="separador"></td></tr>
                  </table>
            </td>
            </tr>
            
        </table>
        
        <table width="100%">
            <tr>
                <td>
                    <table class="datagrid" width="100%" border="0" cellspacing="0">
                        <tr>
                            <td  height="3px" class="separador"></td></tr>
                        <tr class="tabla_columns">
                            <td >SERVICIOS</td>
                        </tr>
                        <tr>
                            <td>
                                <table border='0' cellspacing='0' cellsppadding='0'>
                                    <tr>
                                        <td>
                                            
                                            <?php

                                                if($ingreso!='null' && $ingreso!=""){
                                                   $query = "select id_tipo_servicio,descripcion from cat_tipo_servicios where id_tipo_servicio in (select id_tipo_servicio from rel_tipo_ingreso_servicio where id_tipo_ingreso in (select id_tipo_ingreso from montos where id_ingreso='$ingreso'))";
                                                echo "<table border='0' cellspacing='0' cellsppadding=0><tr><td>";
                                            
                                                    echo "<table id='services' width='100%' border='0' cellspacing='0'>";
                                                    
                                                    $result = mysqli_query($conexion,$query);
                                                    if(mysqli_num_rows($result))
                                                    while(list($id,$nombre)=mysqli_fetch_array($result)){
                                                        echo "<tr><td>";
			                                            echo "$nombre";
                                                        echo "</td></tr>";
                                                        
                                                    }
                                                else{
                                                    echo "<tr><td>No asignado</td></tr>";	
                                                }
                                                
                                                echo "</table></td></tr>";
                                                
                                                echo "</table>";
                                                    
                                                    }else{
                                                        
                                                    $conta=0;
                                                    
                                                   
                                                    echo "<table border='0' cellspacing='0' cellsppadding=0><tr><td>";
                                                
                                                        echo "<table id='services' width='100%' border='0' cellspacing='0'>";
                                                        
                                                        foreach($lista as $valores){
                                                            $conta++;
                                                            echo "<tr id='dinamicon_$conta'><td>";
                                                            $query = "select descripcion from cat_tipo_servicios where id_peticion='$peticion' and id_tipo_servicio='$valores'";
                                                                                                                    
                                                            $result = mysqli_query($conexion,$query);
                                                            list($nombre)=mysqli_fetch_array($result);
                                                               echo "$nombre";
                                                                                                                       
                                                            echo "</tr>";
                                                    }
                                                    echo "</table></td></tr>";
                                                    echo "</table>";	
                                                    }
                                            ?>
                                            <table id='services' width='100%' border='0' cellspacing='0'>
                                            </table>
                                            
                                           
                                        
                                        </td>
                                     </tr>
                                     
                                </table>    
                            </td>    
                        </tr>
                        <tr><td  height="3px" class="separador"></td></tr>
                    </table>    
                </td>
            </tr>
        </table>
        
        <table border="0px"  width="100%" style="color:#000000;font-size:12px">
        <tr>
            <td>
                <table border="0px"  width="100%" cellspacing="0" cellpadding="0" style="color:#000000;font-size:12px">
                <tr><td height="10px"></td></tr>
                    <tr>
                        <td colspan="3">
                            <table class="datagrid" id="materiales" width="100%" border="0" cellspacing="0">
                                <tr><td colspan="6"  height="3px" class="separador"></td></tr>
                                <tr class="tabla_columns">
                                    <td colspan="2">Lista de Materiales en Buen Estado</td>
                                    <td colspan="3">Lista de Materiales de Reemplazo</td>
                                    <td></td>
                                </tr>
                                <tr style="background:#CCC">
                                    <td>Nombre</td>
                                    <td>Cantidad</td>
                                    <td>Nombre</td>
                                    <td>Cantidad</td>
                                    <td>Comentario</td>
                                    <td></td>
                                </tr>
                                <?php
							
								
                                if(isset($_GET['id']))
									$id=$_GET['id'];
								
								if(isset($_POST['select'])){
									$aux=array_keys($_POST['select']);
									$id=$aux[0];
								}
								
                               $material = "select id_material,
								(select descripcion from cat_equipos_inventario where id_equipo_inventario=nom_bueno),cantidad_bueno,
								(select descripcion from cat_equipos_inventario where id_equipo_inventario=nom_reemplazo),
								  cantidad_reemplazo,comentario from material where id_reporte='".addslashes($id)."'";
                                $resultado = mysqli_query($conexion,$material);
                                $row = mysqli_num_rows($resultado);
                                
                                $contador=0;
                                while(list($id,$bueno,$can_bueno,$reemplazo,$can_reemplazo,$comentario)=mysqli_fetch_array($resultado)){
                                    echo "<tr id='".(++$contador)."'>";
                                    echo "<td>$bueno</td>";
                                    echo "<td>$can_bueno</td>";
                                    echo "<td>$reemplazo</td>";
                                    echo "<td>$can_reemplazo</td>";
                                    echo "<td>$comentario</td>";
                                    echo "<input type='hidden' name='ids[$id]' />
                                    </td></tr>";
                                }
                                ?>
                                   
                            </table>
                             
                        </td>
                    </tr>  
                     <tr><td colspan="6" height="3px" class="separador"></td></tr> 
                     <tr><td></td></tr>   
                    
                               
                </table>
                </td>
            </tr>
        </table>


            
        <?php			
		}
	}
}
?>



