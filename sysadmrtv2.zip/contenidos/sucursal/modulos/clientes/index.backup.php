<script language="javascript" type="text/javascript">
	function seleccionar()
	{
		if(document.datagrid.selector.checked)
		{
			for(var i = 1; i<document.datagrid.elements.length; i++)
			{
				document.datagrid.elements[i].checked = true;
			
			}
		}
		else
		{
			for(var i = 1; i<document.datagrid.elements.length; i++)
			{
				document.datagrid.elements[i].checked = false;
			
			}
		}
	}
	function editar()
	{
		var contador=0;
		for(var j = 1; j<document.datagrid.elements.length; j++)
		{
			if(document.datagrid.elements[j].checked)
			{
				contador++;
			}
		}
		if(contador==1)
		{
			document.datagrid.action = "index.php?menu=10&accion=editar"
			document.datagrid.submit();
		}
		else
		{
			if(contador==0)
				window.alert("No ha seleccionado nada.");
			else
				window.alert("Solo puede seleccionar 1 registro");
		}
	}
	
	function imprimir_pdf()
	{		
		var aux_action = document.datagrid.action;
		var aux_target = document.datagrid.target;
		document.datagrid.action = "reporte/clientes_pdf.php";
		document.datagrid.target = "_blank";
		document.datagrid.submit();
		document.datagrid.action = aux_action;
		document.datagrid.target = aux_target;
			
	}
	function imprimir_excel()
	{
		var aux_action = document.datagrid.action;
		var aux_target = document.datagrid.target;
		document.datagrid.action = "reporte/clientes_excel.php";
		document.datagrid.target = "_blank";
		document.datagrid.submit();
		document.datagrid.action = aux_action;
		document.datagrid.target = aux_target;
	}
	
	function contrato()
	{
		var contador=0;
		for(var j = 1; j<document.datagrid.elements.length; j++)
		{
			if(document.datagrid.elements[j].checked)
			{
				contador++;
			}
		}
		if(contador==1)
		{
			var aux_action = document.datagrid.action;
			var aux_target = document.datagrid.target;
			document.datagrid.action = "reporte/imprimir_contrato.php";
			document.datagrid.target = "_blank";
			document.datagrid.submit();
			document.datagrid.action = aux_action;
			document.datagrid.target = aux_target;

		}
		else
		{
			if(contador==0)
				window.alert("No ha seleccionado nada.");
			else
				window.alert("Solo puede seleccionar 1 registro");
		}
	}
	
	//Se han agregado estas dos variables obligatorias 
	var contenedor_cliente = ""; //Se actualiza para saber en que input se coloca la llave del cliente
	var parametro_sucursal_cliente = "<?php echo $_SESSION['tuvision_id_sucursal']; ?>";// Se utiliza en caso de que queramos la lista de clientes de una sucursal en especifica
	function cambio_id_cliente(id){	}
	/*
	function eliminar()
	{
		document.datagrid.accion.value = "eliminar";
		var checado="no";
		for(var j = 1; j<document.datagrid.elements.length; j++)
		{
			if(document.datagrid.elements[j].checked)
			{
				checado = "si";
			}
		}
		if(checado=="si")
		{
			if(window.confirm("¿Estás seguro de ELIMINAR los registros seleccionados?"))
				document.datagrid.submit();
		}
		else
		{
			window.alert("No ha seleccionado ningun registro");
		}
	}
	*/
</script>
<div style="display:none" id="filtro_div"></div>
<table border="0px"  width="100%" style="color:#000000;font-size:12px">
	<tr>    
    	<td align="right">
        	<table border="0" width="100%" cellpadding="0" cellspacing="0" >
            	<tr>
            	<td width="5px" background="imagenes/module_left.png"></td>
                <td width="70px" background="imagenes/module_center.png" height="80"  valign="middle"><img src="imagenes/usuarios.png" /></td>
                <td align="left" background="imagenes/module_center.png" height="80" valign="middle" class="titulo"><b>&nbsp;&nbsp;CLIENTES&nbsp;&nbsp;</b></td>
                <td align="right" background="imagenes/module_center.png" height="80" >
                	<button class="boton2" onclick="createWindow('Filtro',480,300 ,7,false,true);" ><img src="imagenes/filter.png" /><br/>Filtro</button>
                    <button class="boton2" onclick="contrato();" ><img src="imagenes/imprimir.png" /><br/>Contrato</button>
					<?php
				   		if(isset($_POST['aplicar_filtro']))
						{
				   ?>
                    		<button class="boton2" onclick="imprimir_pdf()" ><img src="imagenes/imprimir.png" /><br/>PDF</button>
                            <button class="boton2" onclick="imprimir_excel()" ><img src="imagenes/imprimir.png" /><br/>EXCEL</button>
                    <?php
						}
					?>
                    <button class="boton2" onclick="location.href='index.php?menu=10&accion=agregar'" ><img src="imagenes/agregar.png" /><br/>Agregar</button>
					<button class="boton2" onclick="editar()"><img src="imagenes/editar.png" /><br />Editar</button>
					<!--<button class="boton2" onclick="eliminar()"><img src="imagenes/eliminar.png" /><br />Eliminar</button>-->
                </td>
                <td width="5px" background="imagenes/module_right.png"></td>
                </tr>
            </table>
        </td>
	</tr>
	<?php
		if(isset($_POST['accion']))
		{
			switch($_POST['accion'])
			{
				case 'editar':
					$_POST['calle'] = addslashes($_POST['calle']);
					$_POST['nombre'] = addslashes(strtoupper($_POST['nombre']));
					$_POST['apellido_paterno'] = addslashes(strtoupper($_POST['apellido_paterno']));
					$_POST['apellido_materno'] = addslashes(strtoupper($_POST['apellido_materno']));
					$_POST['numero'] = addslashes(strtoupper($_POST['numero']));
					$_POST['tarifa'] = addslashes(strtoupper($_POST['tarifa']));
					$_POST['num_contrato'] = addslashes(strtoupper($_POST['num_contrato']));
					$_POST['fecha_contrato'] = addslashes(strtoupper($_POST['fecha_contrato']));
					$_POST['referencia_casa'] = addslashes(strtoupper($_POST['referencia_casa']));
					
					if(isset($_POST['tap']))
					{
						if($_POST['tap']=='null')
						{
							$tap = "NULL";
						}
						else
						{
							$tap = "'".addslashes($_POST['tap'])."'";
						}
					}
					else
					{
						$tap = "NULL";
					}
					
					$query = "update clientes set nombre='".$_POST['nombre']."',apellido_paterno='".$_POST['apellido_paterno']."', apellido_materno='".$_POST['apellido_materno']."', numero='".$_POST['numero']."', tarifa=".$_POST['tarifa'].", id_calle=".$_POST['calle'].",  num_contrato='".$_POST['num_contrato']."', fecha_contrato='".$_POST['fecha_contrato']."', referencia_casa='".$_POST['referencia_casa']."', id_tap=".$tap."   where id_cliente='".addslashes($_POST['id'])."'";
					
					if(mysqli_query($conexion,$query))
					{
						?>
							<tr>
                            	<td colspan="3" align="center" >
                                	<table border="0" width="100%" cellpadding="0" cellspacing="0" >
                                		<tr>                                    	
                                        	<td width="5px" background="imagenes/message_left.png"></td>
	                                        <td align="center" background="imagenes/message_center.png" height="30" valign="middle" class="fine">Los datos fueron editados correctamente</td>
    	                                    <td width="5px" background="imagenes/message_right.png"></td>
                                        </tr>
                                    </table>                           
                            	</td>
                           </tr>
						<?php
							
					}
					else
					{
						?>
						<tr>
                        	<td colspan="3" align="center">
                            	<table border="0" width="100%" cellpadding="0" cellspacing="0" >
                                    <tr>                                    	
                                        <td width="5px" background="imagenes/message_error_left.png"></td>
                                        <td align="center" background="imagenes/message_error_center.png" height="30" valign="middle" class="warning">Hubo un problema al editar los datos.</td>
                                        <td width="5px" background="imagenes/message_error_right.png"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
						<?php
					}
					break;
					
				case 'agregar':
					
					$_POST['calle'] = addslashes($_POST['calle']);
					$_POST['nombre'] = addslashes(strtoupper($_POST['nombre']));
					$_POST['apellido_paterno'] = addslashes(strtoupper($_POST['apellido_paterno']));
					$_POST['apellido_materno'] = addslashes(strtoupper($_POST['apellido_materno']));
					$_POST['numero'] = addslashes(strtoupper($_POST['numero']));
					$_POST['tarifa'] = addslashes(strtoupper($_POST['tarifa']));
					$_POST['num_contrato'] = addslashes(strtoupper($_POST['num_contrato']));
					$_POST['fecha_contrato'] = addslashes(strtoupper($_POST['fecha_contrato']));
					$_POST['referencia_casa'] = addslashes(strtoupper($_POST['referencia_casa']));
					
					if(isset($_POST['tap']))
					{
						if($_POST['tap']=='null')
						{
							$tap = "NULL";
						}
						else
						{
							$tap = "'".addslashes($_POST['tap'])."'";
						}
					}
					else
					{
						$tap = "NULL";
					}
					
					
					//Calcular la siguiente clave del cliente
					$siguiente_subclave_query = "select MAX(SUBSTR(id_cliente,4))+ 1 AS SIGUIENTE from clientes where id_sucursal='".$_SESSION['tuvision_id_sucursal']."'";
					$subclave_generada = devolverValorQuery($siguiente_subclave_query);
					if($subclave_generada[0] =="")
					{
						$subclave_generada[0] = '1';
					}
					
					$total_digitos =  strlen($subclave_generada[0]);
					
					//Agregamos 0 a la derecha del digito hasta completar el formato XXX00000
					
					for($i=$total_digitos;$i<5;$i++)
					{
						$subclave_generada[0] = '0'.$subclave_generada[0];
					}
					
					$clave = $_SESSION['tuvision_id_sucursal'].$subclave_generada[0];
					
					 $query = "insert into clientes (id_cliente,id_sucursal, id_tipo_status, id_calle, nombre, apellido_paterno, apellido_materno, numero, tarifa, num_contrato, fecha_contrato, referencia_casa,fecha_registro,id_tap ) values ('".$clave."','".$_SESSION['tuvision_id_sucursal']."',11,'".$_POST['calle']."','".$_POST['nombre']."','".$_POST['apellido_paterno']."','".$_POST['apellido_materno']."','".$_POST['numero']."',".$_POST['tarifa'].",'".$_POST['num_contrato']."','".$_POST['fecha_contrato']."','".$_POST['referencia_casa']."','".date('Y-m-d')."',".$tap.")";
					
					if(mysqli_query($conexion,$query))
					{
						?>
							<tr>
                            	<td colspan="3" align="center" >
                                	<table border="0" width="100%" cellpadding="0" cellspacing="0" >
                                		<tr>                                    	
                                        	<td width="5px" background="imagenes/message_left.png"></td>
	                                        <td align="center" background="imagenes/message_center.png" height="30" valign="middle" class="fine">Los datos fueron agregados correctamente</td>
    	                                    <td width="5px" background="imagenes/message_right.png"></td>
                                        </tr>
                                    </table>                           
                            	</td>
                           </tr>
						<?php
					}
					else
					{
						?>
						<tr>
                        	<td colspan="3" align="center">
                            	<table border="0" width="100%" cellpadding="0" cellspacing="0" >
                                    <tr>                                    	
                                        <td width="5px" background="imagenes/message_error_left.png"></td>
                                        <td align="center" background="imagenes/message_error_center.png" height="30" valign="middle" class="warning">Hubo un problema al agregar los datos.</td>
                                        <td width="5px" background="imagenes/message_error_right.png"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
						<?php
					}
					break;
				/*
				case 'eliminar':
					foreach($_POST as $variable => $valor)
					{
						if($variable != "selector")
						{
							if($variable != "accion")
							{
								$query_eliminar = "DELETE FROM sucursales WHERE id_sucursal='".addslashes($variable)."'";
								if(mysqli_query($conexion,$query_eliminar))
									$bandera = true;
									
								else
									$bandera=false;											
							} 
						}
					}
					if($bandera)
					{
						?>
						<tr>
                        	<td colspan="3" align="center">
                            	<table border="0" width="100%" cellpadding="0" cellspacing="0" >
                                    <tr>                                    	
                                        <td width="5px" background="imagenes/message_left.png"></td>
                                        <td align="center" background="imagenes/message_center.png" height="30" valign="middle" class="fine">Los registros fueron eliminados.</td>
                                        <td width="5px" background="imagenes/message_right.png"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
						<?php
					}
					else
					{
						?>
						 <tr>
                        	<td colspan="3" align="center">
                            	<table border="0" width="100%" cellpadding="0" cellspacing="0" >
                                    <tr>                                    	
                                        <td width="5px" background="imagenes/message_error_left.png"></td>
                                        <td align="center" background="imagenes/message_error_center.png" height="30" valign="middle" class="warning">Hubo un problema al eliminar los registros.</td>
                                        <td width="5px" background="imagenes/message_error_right.png"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
						<?php
					}
					break;
				*/
			}
		}
	?>
    <tr><td height="10px"></td></tr>
	<tr>
		<td colspan="3">
			<form name="datagrid" method="post">
			<table class="datagrid" width="100%" border="0" cellspacing="0">
				<tr><td colspan="7" height="3px" class="separador"></td></tr>
				<tr class="tabla_columns">
                    <td>Clave</td>
                    <td>Nombre</td>
                    <td>Sucursal</td>
                    <td>Estatus</td>
                    <td>Tipo Estatus</td>
                    <td>Fecha Activacion</td>
					<td align="center" width="50px"><input type="checkbox" name="selector" onclick="seleccionar()" /><input type='hidden'name='accion'/></td>
				</tr>
                
				<?php
					
					if(isset($_POST['aplicar_filtro']))
					{
						$add_query="";
						
						if($_POST['id_cliente']!="")
						{
							$add_query .= " and c.id_cliente='".addslashes($_POST['id_cliente'])."' ";
						}
						
						
						
						if($_POST['status']!="")
						{
							$add_query .= " and sc.id_status='".addslashes($_POST['status'])."' ";
						}
						
						
						if($_POST['fecha_registro_desde']!=""&& $_POST['fecha_registro_hasta']!="")
						{
							$add_query .= " and c.fecha_registro between '".addslashes($_POST['fecha_registro_desde'])."' and '".addslashes($_POST['fecha_registro_hasta'])."' ";
						}
						
						if($_POST['fecha_contrato_desde']!=""&& $_POST['fecha_contrato_hasta']!="")
						{
							$add_query .= " and c.fecha_contrato between '".addslashes($_POST['fecha_contrato_desde'])."' and '".addslashes($_POST['fecha_contrato_hasta'])."' ";
						}
						
						if($_POST['fecha_activacion_desde']!=""&& $_POST['fecha_activacion_hasta']!="")
						{
							$add_query .= " and c.fecha_activacion between '".addslashes($_POST['fecha_activacion_desde'])."' and '".addslashes($_POST['fecha_activacion_hasta'])."' ";
						}
						
						
						
						
						
						
						
						$query = "select c.id_cliente, concat(c.nombre,' ',c.apellido_paterno,' ',c.apellido_materno), s.nombre, sc.descripcion, tsc.descripcion, c.fecha_contrato, c.fecha_activacion from clientes c, sucursales s, estatus_cliente sc, tipo_status_cliente tsc where c.id_sucursal= s.id_sucursal and c.id_tipo_status = tsc.id_tipo_status and tsc.id_status= sc.id_status and c.id_sucursal='".$_SESSION['tuvision_id_sucursal']."'  ".$add_query." order by c.id_sucursal asc, c.id_cliente asc";
						
						$query2 = "select c.id_cliente, concat(c.nombre,' ',c.apellido_paterno,' ',c.apellido_materno), s.nombre, sc.descripcion, tsc.descripcion, c.fecha_contrato, c.fecha_activacion, concat(tap.id_tap,'-',tap.valor,'-',tap.salidas), cc.nombre, c.numero, c.referencia_casa  from clientes c, sucursales s, estatus_cliente sc, tipo_status_cliente tsc, tap, cat_calles cc where cc.id_calle=c.id_calle and tap.id_tap=c.id_tap and c.id_sucursal= s.id_sucursal and c.id_tipo_status = tsc.id_tipo_status and tsc.id_status= sc.id_status and c.id_sucursal='".$_SESSION['tuvision_id_sucursal']."' ".$add_query." order by c.id_sucursal asc, c.id_cliente asc";
						
						$_SESSION['tuvision_filtro_clientes'] = $query;
						$_SESSION['tuvision_filtro_clientes2'] = $query2;
						
						$tabla = mysqli_query($conexion,$query);
						while($registro=mysqli_fetch_array($tabla))
						{
							$bandera = true;
							?>
								<tr class="tabla_row">
									<td><a href="index.php?menu=10&accion=editar&id=<?php echo $registro[0];  ?>"><?php echo $registro[0]; ?></a></td>
									<td><a href="index.php?menu=10&accion=editar&id=<?php echo $registro[0];  ?>"><?php echo $registro[1]; ?></a></td>
									<td><a href="index.php?menu=10&accion=editar&id=<?php echo $registro[0];  ?>"><?php echo $registro[2]; ?></a></td>
									<td><a href="index.php?menu=10&accion=editar&id=<?php echo $registro[0];  ?>"><?php echo $registro[3]; ?></a></td>
                                    <td><a href="index.php?menu=10&accion=editar&id=<?php echo $registro[0];  ?>"><?php echo $registro[4]; ?></a></td>
                                     <td><a href="index.php?menu=10&accion=editar&id=<?php echo $registro[0];  ?>"><?php echo $registro[6]; ?></a></td>
									<td align="center"><input type="checkbox" name="<?php echo $registro[0];  ?>" /></td>
								</tr>
							<?php
						}
						if(!$bandera)
						{
							?>
							<tr><td colspan="7">No hay Registros</td></tr>
							<?php
						}
					}
					else
					{
						?>
							<tr><td colspan="7">Ultilice el bot&oacute;n <b>"Filtro"</b> para hacer una b&uacute;squeda de registros</td></tr>
						<?php
					}
				?>
				<tr><td colspan="7"  height="3px" class="separador"></td></tr>
			</table>
			</form>
		</td>
	</tr>
</table>